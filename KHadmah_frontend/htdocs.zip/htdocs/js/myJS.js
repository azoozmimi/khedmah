jQuery(function($){
/*loading --------------------------*/
	var links = document.getElementsByTagName("a"),
i = 0, l = links.length,
body = document.body;

for(;i<l;i++) {
    links[i].addEventListener("click",function(){
         $("#overlay").fadeIn(100);
        setTimeout(function(){
          $("#overlay").fadeOut(100);
		
        },3000);
    },false);
}
/*loading --------------------------*/

function monthFormated(date) {
   if(!date)
     date = new Date();

     month = date.getMonth();
 
    return month < 9 ? "0" + (month+1) : month+1;
}
/*-----------money */
});/*end of documnet ready------------*/


