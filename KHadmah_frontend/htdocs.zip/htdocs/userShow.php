<style>#loader-11 { width: 100%; height: 100%; z-index: 2; } #loader-11 #loader:first-child div { display: block; width: 100px; height: 100px; border: 3px solid #ddd; border-radius: 50%; position: absolute; top: 0; right: 0; bottom: 0; left: 0; margin: auto; } #loader-11 #loader:first-child>div>div { width: 90px; height: 90px; border: 5px solid #000; border-radius: 50%; margin: auto; overflow: hidden; } #loader-11 #loader:first-child div div div { width: 110px; height: 110px; margin: auto; top: 360px; background-color: #ddd; border-radius: 0%; border: none; -webkit-animation: anim 3s ease infinite alternate, color 4s ease infinite alternate; -moz-animation: anim 3s ease infinite alternate, color 4s ease infinite alternate; -o-animation: anim 3s ease infinite alternate, color 4s ease infinite alternate; animation: anim 3s ease infinite alternate, color 4s ease infinite alternate; } @-webkit-keyframes anim { 100% { top: 0 } } @-moz-keyframes anim { 100% { top: 0 } } @-o-keyframes anim { 100% { top: 0 } } @keyframes anim { 100% { top: 0 } } @-webkit-keyframes color { 0% { background-color: green; } 25% { background-color: green; } 50% { background-color: red; } 75% { background-color: yellow; } 100% { background-color: blue; } } @-moz-keyframes color { 0% { background-color: green; } 25% { background-color: green; } 50% { background-color: red; } 75% { background-color: yellow; } 100% { background-color: blue; } } @-o-keyframes color { 0% { background-color: green; } 25% { background-color: green; } 50% { background-color: red; } 75% { background-color: yellow; } 100% { background-color: blue; } } @keyframes color { 0% { background-color: green; } 25% { background-color: green; } 50% { background-color: red; } 75% { background-color: yellow; } 100% { background-color: blue; } } </style>
<div class="loader-wrapper" id="loader-11" style='z-index:100;'>
    <div id="loader">
        <div>
            <div>
                <div>
                </div>
            </div>
        </div>
    </div>
    </div>
<script>
    loaders = document.getElementsByClassName('loader-wrapper');
    loaders[0].style.display = "inherit";

    function change(self) {
	
        for (var i = loaders.length - 1; i >= 0; i--) {
		
            loaders[i].style.display = "none";
        }
        id = self.id;
        loaders[id - 1].style.display = "inherit";
    };
    </script>

<?php
require("head.php");
if(empty($_SESSION["userName"])){ echo"<script> location.replace('index.php'); </script>";}
?>
<div class="card divWelcomeUser" >
	
		مرحباً: <?php echo $_SESSION['userName']; ?> 
		<?php $trantID=$_SESSION['userID']; echo "<input type='number'hidden id='trantID' value='$trantID'>"; ?> 
	
</div>

<center id="ContainerShow" style='display:none'>

 		 	<div class="labelImageContainer " style=" margin:2%;">
				
				<select id="showBillMonth" class="labelImageButton" style='color:black'>
				<option value="null" selected>اضغط...لعرض الفاتورة بحسب الشهر</option>
				<option value="01">عرض الفاتورة بحسب شهر(1)</option>
				<option value="02">عرض الفاتورة بحسب شهر(2)</option>
				<option value="03">عرض الفاتورة بحسب شهر(3)</option>
				<option value="04">عرض الفاتورة بحسب شهر(4)</option>
				<option value="05">عرض الفاتورة بحسب شهر(5)</option>
				<option value="06">عرض الفاتورة بحسب شهر(6)</option>
				<option value="07">عرض الفاتورة بحسب شهر(7)</option>
				<option value="08">عرض الفاتورة بحسب شهر(8)</option>
				<option value="09">عرض الفاتورة بحسب شهر(9)</option>
				<option value="10">عرض الفاتورة بحسب شهر(10)</option>
				<option value="11">عرض الفاتورة بحسب شهر(11)</option>
				<option value="12">عرض الفاتورة بحسب شهر(12)</option>
			  </select>
				
 	 			</div>
				<div id="showBillUser" class="labelImageContainer">
					
					
				</div>
				</center>				
<script>

jQuery(function($){
	$("#loader-11").fadeOut();
	$("#ContainerShow").fadeIn();
	 $("#showBillUser").html('يرجى احتيار الشهر ');
		  $("#showBillUser").append($("#loader-11").fadeIn());
	/*$("#errorAdHose").href="#popup2";*/
jQuery(".divWelcomeUser").slideDown("slow");
jQuery(document).ajaxSend(function() {
    jQuery("#overlay").slideDown(300);　
  });
  $('#showBillMonth').click(function(){$('#showBillMonth').css("color","black")});
function monthFormated(date) {
   if(!date)
     date = new Date();

     month = date.getMonth(); 
    return month < 9 ? "0" + (month) : month+1;
}	
$("#showBillMonth").change(function(){
	var e = document.getElementById("showBillMonth");
var month = e.value;

if(month!='null'){
	var monthSendData=new FormData();
	monthSendData.append('month',jQuery("#showBillMonth").val());
	monthSendData.append('trantID',jQuery("#trantID").val());
	
	$.ajax({
      type: 'POST',
		contentType: false,
          processData: false,
		url:"config/showUserConfig.php",
		data: monthSendData,
      success: function(data){
        $("#showBillUser").html(data);
      },
      error: function(xhr, status, error) {
          $("#showBillUser").html("<p>Error: " + error + "</p>");
    }
    }).done(function() {
      setTimeout(function(){
        $("#overlay").fadeOut(300);
      },500);
    });
	}else{
		
		 $("#showBillUser").html('يرجى احتيار الشهر ');
		  $("#showBillUser").append($("#loader-11").fadeIn());
	}
/*end of send fun*/


	
});
});/*end doc fun*/
</script>
<?php
require_once("footer.php");
