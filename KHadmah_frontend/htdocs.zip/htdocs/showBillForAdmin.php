<style>#loader-11 { width: 100%; height: 100%; z-index: 2; } #loader-11 #loader:first-child div { display: block; width: 100px; height: 100px; border: 3px solid #ddd; border-radius: 50%; position: absolute; top: 0; right: 0; bottom: 0; left: 0; margin: auto; } #loader-11 #loader:first-child>div>div { width: 90px; height: 90px; border: 5px solid #000; border-radius: 50%; margin: auto; overflow: hidden; } #loader-11 #loader:first-child div div div { width: 110px; height: 110px; margin: auto; top: 360px; background-color: #ddd; border-radius: 0%; border: none; -webkit-animation: anim 3s ease infinite alternate, color 4s ease infinite alternate; -moz-animation: anim 3s ease infinite alternate, color 4s ease infinite alternate; -o-animation: anim 3s ease infinite alternate, color 4s ease infinite alternate; animation: anim 3s ease infinite alternate, color 4s ease infinite alternate; } @-webkit-keyframes anim { 100% { top: 0 } } @-moz-keyframes anim { 100% { top: 0 } } @-o-keyframes anim { 100% { top: 0 } } @keyframes anim { 100% { top: 0 } } @-webkit-keyframes color { 0% { background-color: green; } 25% { background-color: green; } 50% { background-color: red; } 75% { background-color: yellow; } 100% { background-color: blue; } } @-moz-keyframes color { 0% { background-color: green; } 25% { background-color: green; } 50% { background-color: red; } 75% { background-color: yellow; } 100% { background-color: blue; } } @-o-keyframes color { 0% { background-color: green; } 25% { background-color: green; } 50% { background-color: red; } 75% { background-color: yellow; } 100% { background-color: blue; } } @keyframes color { 0% { background-color: green; } 25% { background-color: green; } 50% { background-color: red; } 75% { background-color: yellow; } 100% { background-color: blue; } } </style>
<div id="showLoader-11">
<div class="loader-wrapper" id="loader-11">
    <div id="loader">
        <div>
            <div>
                <div>
                </div>
            </div>
        </div>
    </div>
    </div>
</div>
<script>
    loaders = document.getElementsByClassName('loader-wrapper');
    loaders[0].style.display = "inline-block";

    function change(self) {
	
        for (var i = loaders.length - 1; i >= 0; i--) {
		
            loaders[i].style.display = "none";
        }
        id = self.id;
        loaders[id - 1].style.display = "inline-block";
    };
    </script>
<?php
require("head.php");
if(empty($_SESSION["userName"])){ echo"<script> location.replace('index.php'); </script>";}
else if($_SESSION["grant"]=="trant"){echo"<script> location.replace('userShow.php'); </script>";}

?>		
<div class="card divWelcomeUser">
	
		مرحباً: <?php echo $_SESSION['userName']; ?> 
		<a href='home.php'><span class='fa fa-home'></span></a>
	
</div>
<section class="flats-sectionTop card">
	<table>
		<tr>
				<label>
					
						<input type="number"id="flatsNumber" placeholder="رقم الشقه">
						
					
					<div class="label-text"> <i class="fa fa-home"></i>
						رقم الشقه</div>
				</label>
				<label>
					
					<div class="label-text">
						<h5 id="userFlatsName"></h5>
						<input id="userFlatsID" type="text" hidden>
						
						<input id="userID" type="text" hidden >
					
					</div>
				</label>
			
		</tr>
		<tr class="">
		<select id="showBillMonth" class="select-css">
				<option value="01">عرض فاتورة لشهر(1)</option>
				<option value="02">عرض فاتورة لشهر(2)</option>
				<option value="03">عرض فاتورة لشهر(3)</option>
				<option value="04">عرض فاتورة لشهر(4)</option>
				<option value="05">عرض فاتورة لشهر(5)</option>
				<option value="06">عرض فاتورة لشهر(6)</option>
				<option value="07">عرض فاتورة لشهر(7)</option>
				<option value="08">عرض فاتورة لشهر(8)</option>
				<option value="09">عرض فاتورة لشهر(9)</option>
				<option value="10">عرض فاتورة لشهر(10)</option>
				<option value="11">عرض فاتورة لشهر(11)</option>
				<option value="12">عرض فاتورة لشهر(12)</option>
			  </select>
			<br>
		</tr>
		</table>
		<center>
		<div id="showBillUser" class="labelImageContainer">
		</center>
</section>
<script>
$(".divWelcomeUser").slideDown();
$(".loader-wrapper").slideUp();
$("#loader-11").slideUp();
function monthFormated(date) {
   if(!date)
     date = new Date();

     month = date.getMonth(); 
    return month < 9 ? "0" + (month+1) : month+1;
};
	$('#showBillMonth').val(monthFormated()).change();
	
	
	var e = document.getElementById("showBillMonth");
var month = e.value;

function getFlatsTrants(){
	$(document).ajaxSend(function() {
    $("#overlay").fadeIn(300);　
  });
		
	var fltsNmberF=new FormData();
	fltsNmberF.append('flatsNumber',jQuery('#flatsNumber').val());
	fltsNmberF.append('billDate',jQuery("#showBillMonth").val());
	
    $.ajax({
      type: 'POST',
		contentType: false,
          processData: false,
		url: 'config/getUserFlatsName.php',
		data: fltsNmberF,
      success: function(data){
        $("#userFlatsName").html(data);
		getMonthDeatails();
      }
    }).done(function() {
      setTimeout(function(){
        $("#overlay").fadeOut(300);
      },500);
    });
}
function getMonthDeatails(){
	var e = document.getElementById("showBillMonth");
var month = e.value;

if(month!='null'){
	var monthSendData=new FormData();
	monthSendData.append('month',jQuery("#showBillMonth").val());
	monthSendData.append('trantID',jQuery("#userFlatsID").val());
	
	$.ajax({
      type: 'POST',
		contentType: false,
          processData: false,
		url:"config/showUserConfig.php",
		data: monthSendData,
      success: function(data){
        $("#showBillUser").html(data);
      }
    }).done(function() {
      setTimeout(function(){
        $("#overlay").fadeOut(300);
      },500);
    });
	}else{
		
		 $("#showBillUser").html('يرجى احتيار الشهر ');
		  $("#showBillUser").append($("#loader-11").fadeIn());
	}
/*end of send fun*/


}
$("#showBillMonth").change(function(){getMonthDeatails();});
	
$("#flatsNumber").change(function(){getFlatsTrants();});/*end flatsNumber change--------------*/
</script>
<?php require_once("footer.php");?>
<!------------------------------------------>