<?php
require_once("head.php");
if(empty($_SESSION["userName"])){header("location: login.php");exit();}
else if($_SESSION["grant"]=="trant"){header("location: userShow.php");exit();}
?>
<div class="card divWelcomeUser">
	
		مرحباً: <?php echo $_SESSION['userName']; ?> 
		<a href='home.php'><span class='fa fa-home'></span></a>
	
</div>


			<center class="card-group col-lg-12 col-md-12 col-sm-12" >
				
 		 	<div class="card col-md-4 col-sm-4 " style=" margin:4%;">
					<a href="wEsignUnit.php">
					<div class="faIcon ">
					  <div class="caption"><br>
						 <button class=""> اضافة فاتوره</button>
					  </div>
					</div>
						</a>
 	 			</div>
				<hr>
				<div class="card col-md-4 col-sm-4" style="margin:4%;">
					
					<div class=" faIcon ">
					  <div class="caption"><br>
						 <a href="getBillCash.php"><button>سند قبض</button></a>
					  </div>
					</div>
 	 			</div>
				<hr>
				<div class="card col-md-4 col-sm-4 col-lg-4" style=" margin:4%;">
					
					<div class=" faIcon " >
					  <div class="caption"><br>
						 <a href="reportShow.php"><button> شاشة التقارير</button></a>
					  </div>
					</div>
 	 			</div>
				<div class="card col-md-4 col-sm-4 col-lg-4" style=" margin:4%;">
					
					<div class=" faIcon " >
					  <div class="caption"><br>
						 <a href="countElecWater.php"><button> اجمالي الماء والكهرباء</button></a>
					  </div>
					</div>
 	 			</div>
				<div class="card col-md-4 col-sm-4 col-lg-4" style=" margin:4%;">
					
					<div class=" faIcon " >
					  <div class="caption"><br>
						 <a href="editeUsers.php"><button> تعديل بينات الشقه(المستخدمين)</button></a>
					  </div>
					</div>
 	 			</div>
				  <div class="card col-md-4 col-sm-4 col-lg-4" style=" margin:4%;">
					
					<div class=" faIcon " >
					  <div class="caption"><br>
						 <a href="showBillForAdmin.php"><button> عرض فواتير بحسب الشقة</button></a>
					  </div>
					</div>
 	 			</div>
		</center>
		<center class=" ">
			<hr>
				<div class="card col-md-4 col-sm-4 col-lg-4 " style=" margin:4%;">
					<a class="button" href="bushCash.php" >
					<div class=" faIcon ">
					  <div class="caption"><br>
						 <button>سند صرف</button>
					  </div>
					</div>
					</a>
 	 			</div>	
				
		</center>
		<center class=" ">
			<hr>
				<div class="card col-md-4 col-sm-4 col-lg-4 " style=" margin:4%;">
					<a class="button" href="chargeMoney.php" >
					<div class=" faIcon ">
					  <div class="caption"><br>
						 <button>اضافة ايداع</button>
					  </div>
					</div>
					</a>
 	 			</div>	
				
		</center>
		<center class=" ">
			<hr>
				<div class="card col-md-4 col-sm-4 col-lg-4 " style=" margin:4%;">
					<a class="button" href="addflats.php" >
					<div class=" faIcon ">
					  <div class="caption"><br>
						 <button>اضافة شقه</button>
					  </div>
					</div>
					</a>
 	 			</div>	
				
		</center>
				
				
			
				


<script>
$(function(){
	$(".divWelcomeUser").slideDown();
});

</script>	
<!-----------------------------error pop show-------------------->
<div id="popup2" class="overlay">
	<div class="popup">
		<a class="close " href="#">&times;</a>
		<h1 id="s"></h1>
		
	</div>
</div>
<!-----------------------------error pop show-------------------->

<?php
include("footer.php");

