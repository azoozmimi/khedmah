<?php
require_once("head.php");
if(empty($_SESSION["userName"])){header("location: index.php");}
else if($_SESSION["grant"]=="trant"){header("location: userShow.php");}
?>
<div class="card divWelcomeUser">
	
		مرحباً: <?php echo $_SESSION['userName']; ?> 
	
</div>

		<div class="content" style=" overflow-y: scroll;" >
		<form id="formAddHome" action="#" method="post">
				<label>
					<input type="number" id="hoseNumber" placeholder="رقم الشقه">
				</label>
				<label>
					<input type="text" id="hoseName" placeholder="اسم مستأجر الشقه" required >
				</label>
				<label>
					<input type='number' id="hosePrice"  placeholder="سعر ايجار الشقه" 
				     required >
					 <label>
					 <span id="priceShow"></span>
					 </label>
				</label>
				<label>
					<input type="number" id="hosePhone" placeholder="رقم الهاتف" min="1"  required >
				</label>
				<label>
					<input type="text" id="hosePass" placeholder="كلمة السر"  required >
				</label>	
				<label>
				الصلاحية
				
					<select   id="grant" placeholder="الصلاحية">
						<option value='trant'>trant</option>
						<option value='admin'>admin</option>
					</select>
				</label>
			
				<label>
					<button  type="submit" value="Submit" id="addHoseSubmit" class="button">  حفظ</button>
				</label>
		</form>
		</div>
		<div id="divSapo"></div>	
		
	
<script>

jQuery(function($){

	jQuery(".divWelcomeUser").slideDown("slow");
jQuery(document).ajaxSend(function() {
    jQuery("#overlay").slideDown(300);　
  });


$("#formAddHome").submit(function(){return false;});
	
  jQuery("#addHoseSubmit").click(function(){
	 var num=document.getElementById("hosePrice").value;
	  var homeform = new FormData();
		  homeform.append('hoseNumber',jQuery('#hoseNumber').val());
		  homeform.append('hoseName', jQuery('#hoseName').val());
		  homeform.append('hosePhone', jQuery('#hosePhone').val());
		  homeform.append('hosePass', jQuery('#hosePass').val());
		  homeform.append('hosePrice',num);
		  homeform.append('grant',$("#grant").val());
	
	jQuery.ajax({
      type: 'POST',
		contentType: false,
          processData: false,
			url: 'config/editHomeConfig.php',
          data : homeform,
		success: function(data){
		if(data=='t'){
			$("#divSapo").html('<h1>تمت تعديل شقه برقم('+jQuery('#hoseNumber').val()+')</h1>');
			$("#formAddHome").delay('slow').trigger("reset");
		}else{
			$("#divSapo").html(data);
		}
      },
    }).done(function() {
      setTimeout(function(){
        jQuery("#overlay").fadeOut(300);
      },500);
	  
	  }); /*end of ajax*/

  });/*end of addHose-------------------------*/	
});

</script>	
<?php
require_once('footer.php');	