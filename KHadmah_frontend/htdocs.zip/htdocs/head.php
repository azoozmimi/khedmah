<?php
require_once("config/conn.php");
if(session_status() == PHP_SESSION_NONE){
    session_start();
}
?>
<html dir="rtl">
<head>
  
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <title>BillsFlat</title>
	<meta http-equiv='cache-control' content='no-cache'>
<meta http-equiv='expires' content='0'>
<meta http-equiv='pragma' content='no-cache'>
<script src = "newfile.js?version = 1.1"></script>
<script src="js/myfile.js?t=<?=time()?>" type="text/javascript"></script>
    <link href='css/bootstrap.min.css' rel='stylesheet'>
	  <link href='css/font-awesome.min.css' rel='stylesheet'>
	  <link href='css/myStyle.css?v=<?php echo time(); ?>' rel='stylesheet'>
	 <script src='js/jquery-3.1.1.min.js'></script>
	  <script src='js/bootstrap.min.js'></script>
	 <script src='js/myJS.js'></script>
	  
  
   </head>
	<body>
	
	
		
		<div class='container'>
			<div class='row'>
		
			
				