<?php 

function invoiceShow($conn,$bilID){
if(session_status() == PHP_SESSION_NONE){
    session_start();
}
$trantID=null;
$wID=null;
$elecID=null;
$elecBef=null;
$elecNow=null;
$elecUPrice=null;
$elecSignPrice=null;
$wBef=null;
$wNow=null;
$wUPrice=null;
$wSignPrice=null;
$billNote="";
$flatPrice=0;
$remainingT=0;
$phoneNum=0;
try{
$sql="select * from monthbill where ID=?";
$pdo2=$conn->prepare($sql);
$pdo2->execute([$bilID]);
if($pdo2->rowCount()>0){
$fullInfo2=$pdo2->fetchall();
	foreach($fullInfo2 as $info){
		$billNum=$info['ID'];
		$billDate=$info['dateIDU'];
		$elecNow=$info['elecCount'];
		$elecNow=$info['elecCount'];
		$elecID=$info['elecBillID'];
		$wNow=$info['waterCount'];
		$wID=$info['waterBillID'];
		$trantID=$info['trantID'];
		$billNote=$info['note'];
		$flatPrice=$info['flatPrice'];
		$remaining=$info['remBefore'];
		
	}
}
/*get trantName*/
if($trantID!=null){
$sql2="select * from users where ID=?";
$pdo3=$conn->prepare($sql2);
$pdo3->execute([$trantID]);
if($pdo3->rowCount()>0){
$fullInfo3=$pdo3->fetchall();
	foreach($fullInfo3 as $info3){
		$flatsNum=$info3['flatsNumber'];
		$trantName=$info3['name'];
		$phoneNum=$info3['phone'];
		
	}
}
}else{
	echo"<h4>
	للاسف لم يتم قطع فاتورة في هذا الشهر المحدد !
	يرجى مراجعة المشرف
	</h4><br>";
	exit();
}
/*get trantName*/	
/*get elecBef*/

if($elecID!=null){
$sql4="select * from elecbill where ID=?";
	$pdo4=$conn->prepare($sql4);
	$pdo4->execute([$elecID]);
		$fullInfo4=$pdo4->fetchall();
		
            foreach($fullInfo4 as $info4)
			{
				$elecUPrice=$info4['unitPrice'];
				$elecSignPrice=$info4['signPrice'];
			}
}
/*get elecBef*/
/* get water 5*/
if($wID!=null){
$sql5="select * from waterbill where ID=?";
	$pdo5=$conn->prepare($sql5);
	$pdo5->execute([$wID]);
		$fullInfo5=$pdo5->fetchall();
		
            foreach($fullInfo5 as $info5)
			{
				$wUPrice=$info5['wUnitPrice'];
				$wSignPrice=$info5['wSignPrice'];
			}
}

/* get water 5*/
/*before 6*/
      	
if($trantID!=null){
require_once("config/ourFunctions.php");

$sql6="select * from monthbill where ID=?";
		$date=str_replace($trantID,'',$bilID);
      
         if (strlen($date) >= 4)
        $d=getlastMonth($date[2].''.$date[3]);
        elseif(strlen($date) >=2)
          $d=getlastMonth($bilID[2].''.$bilID[3]);

        if($d==12){
           if (strlen($date) >= 4)
            $getBeforeYear=$date[0].$date[1];
            else
               $getBeforeYear=$bilID[0].$bilID[1];
            $getBeforeYear=(int)$getBeforeYear;
            $getBeforeYear=$getBeforeYear-1;
	        $biilIDBefore=$getBeforeYear.$d.$trantID;
        }else{
        $biilIDBefore=$date[0].''.$date[1].$d.$trantID;
        }
        echo"$biilIDBefore";
	
				$pdo6=$conn->prepare($sql6);
				$pdo6->execute([$biilIDBefore]);
				if($pdo6->rowCount()>0){
				$fullInfo6=$pdo6->fetchall();
				foreach($fullInfo6 as $info6){$elecBef=$info6['elecCount'];$wBef=$info6['waterCount'];}
				}else{$wBef=0;$elecBef=0;}
}
/*before 6*/
$elecTotal=(((Max($elecNow-$elecBef,0))*($elecUPrice))+$elecSignPrice);

$wTotla=((Max($wNow-$wBef,0))*($wUPrice))+$wSignPrice;
$number1=($wTotla+$elecTotal+$flatPrice+$remaining);
$number1=formatMoney($number1,'2');
$mssg=$trantName."___يرجى تسديد ماعليكم من قيمة فاتورة لشهر".$billDate."___اجمالي الفاتورة=".$number1."____يمكنك مراجعة الفاتورة من خلال التطبيق";

}catch(PDOException $x){echo $x->getMessage();}

?>
	<style>
			

			body h1 {
				font-weight: 300;
				margin-bottom: 1px;
				padding-bottom: 1px;
				color: #C73EE5;
			}

			body h3 {
				font-weight: 300;
				margin-top: 10px;
				margin-bottom: 20px;
				font-style:normal;
				color: #C73EE5;
			}

			body a {
				color: #06f;
			}
			#showInvoiceTable{
				font-size:12px
			}

			.invoice-box {
				width:100%;
				margin: auto;
				padding: 20px;
				border: 1px solid #eee;
				box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
				font-size: 16px;
				line-height: 24px;
				
				color:black;
			}

			.invoice-box table {
				width: 100%;
				text-align: right;
				border-collapse: collapse;
			}

			.invoice-box table td {
				padding: 5px;
				vertical-align: top;
				font-size:12px;
			}

			.invoice-box table tr td:nth-child(2) {
				text-align: right;
				font-size:auto;
			}

			.invoice-box table tr.top table td {
				padding-bottom: 12px;
			}

			.invoice-box table tr.top table td.title {
				font-size: 45px;
				line-height: 45px;
				color: #333;
			}

			.invoice-box table tr.information table td {
				padding-bottom: 40px;
			}

			.invoice-box table tr.heading td {
				background: #9829DC;;
				border-bottom: 1px solid black;
				color: white;
			}

			.invoice-box table tr.details td {
				border:1px solid hsla(283,68%,86%,1.00);
				background: hsla(0,9%,94%,0.92);
				
			}
			.invoice-box table tr.item.last td {
				border-bottom: none;
			}

			.invoice-box table tr.total td:nth-child(2) {
				border-top: 1px solid #eee;
				font-weight: bold;
			}

			@media only screen and (max-width: 640px) {
				.invoice-box table tr.top table td {
					width: 70%;
				}

				
				
			}

			.clear{
					clear: both;
				}
		</style>

		
		<div id="invoiceConent2Print" dir="rtl">
				<div class="invoice-box" style="overflow-x:auto;" >
			<table >
							<tr >
								<td style=" ">
									<font style="float:right;">
										<?php echo " رقم الشقة "." (".$flatsNum.") " ?></font>
									
									<font style="float:left;">
										<?php echo ("فاتورة_رقم  $billNum [ $billDate ]") ?></font>
								</td>
							</tr>
						</table><hr>
			<div class="clear"></div>
			<table>
				<tr class="information" >
					<td colspan="4">
						<table id="showInvoiceTable"style="text-align: center">
							<tr >
								<td> 
									<?php echo "اسم_المستأجر ".$trantName ?><br />
							
							<input type="text" value="<?php echo $trantName ?>" hidden id="trantNameu">
								</td>
							</tr>
							
								<?php
	if($billNote!="" || $billNote!=null){
		echo"
		<tr><td><hr>
		ملاحظة:  $billNote
<hr></td></tr>";
	}?>
	<script src="js/html2pdf.bundle.js"></script>

							</table>
						
					</td>
				</tr>
				<tr class="heading">
					<td> </td>
					<td>فاتورة_الكهرباء </td>
					<td>فاتورة_الماء </td>
				
				</tr>

				<tr class="details">
					<td>القراءه_الحاليه</td>
					<td><?php echo $elecNow?></td>
					<td><?php echo $wNow?></td>
				</tr>
				<tr class="details">
					<td>القراءه_السابقة</td>
					<td><?php echo $elecBef?></td>
					<td><?php echo $wBef?></td>
					
				</tr>
				<tr class="details"><td>المستهلكة</td>
				<td><?php echo Max($elecNow-$elecBef,0)?></td>
				<td><?php echo Max($wNow-$wBef,0)?></td>
					
				</tr>
				</tr>
				<tr class="details">
					<td>سعر_الوحدة</td>
					<td><?php echo $elecUPrice?></td>
					<td><?php echo $wUPrice?></td>
				</tr>
				</tr>
				<tr class="details">
					<td>سعر_الاشتراك</td>
					<td><?php echo $elecSignPrice?></td>
					<td><?php echo $wSignPrice?></td>
				</tr>
				<tr class="details" style="background: hsla(295,21%,88%,0.80)">
					<td >الاجمالي</td>
					<td>
			<?php echo formatMoney($elecTotal,".")?>
					</td>
					<td>
			<?php echo formatMoney($wTotla,".");?>
					</td>
				</tr>
				<tr class="heading" style="text-align:center">
				<td colspan="">
					  ايجار_الشقة  
				<?php echo formatMoney($flatPrice,".");
				 ?> 
				</td>
					<td></td>
				<td colspan="">
					
				<?php
				if($remaining<0)
				echo " لك"."<br>".formatMoney($remaining*-1,".");
				else 
				echo 'المتأخرات'."<br>".formatMoney($remaining,".");
				 ?> 
				</td>
				</tr>
		
		
			
			</table><br>
	
				<div class="total" style="text-align: right">
					<h5> 
					<?php echo "  المطلوب من الاخ ".$trantName;?>
					</h5>
 					<h6>
						مبلغ_وقدرة
						<?php 
						$number=($wTotla+$elecTotal+$flatPrice+$remaining);
	
					echo "#".formatMoney( $number,".")."#";
						?>
					</h6>
				</div><hr>
				<?php
				if($_SESSION["grant"]=="admin"){
					$userName= $_SESSION["userName"];
					echo"
				<font style='float:left;font-size: 12px'> اصدرت_بواسطة
				$userName
				</font>
			<p style='float:right;font-size: 12px'> تاريخ_الاصدار ";
				 echo date("Y/m/d");
				}
				?>
				</p>
		</div>
</div>

<?php
if($_SESSION["grant"]=="admin"){
	echo"
<div id='PrintBTN'>
				<table>
				<tr>
				<td>
				<button class=''
							id='printDiv'onclick='invoiceDownload()'	><i class='fa fa-download'></i><br>تنزيل \طباعة</button></td>
						<td></td>
						<td>
						<a href='sms://$phoneNum?body=$mssg'>
						<button class=''><i class='fa fa-envelope'></i>رسالة sms </button></a>
						</td>
						<td></td>
						</tr>		
				</table>
</div>
";}
} 
?>
<script>
jQuery('#invoiceConent2Print').slideDown();
jQuery('.container-Bill').slideUp();

function invoiceDownload(){
	const elementID=document.getElementById("invoiceConent2Print");
		html2pdf()
		.from(elementID)
		.save( '22'+'.pdf');
		
	}

</script>