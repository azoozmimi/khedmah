<?php 
function invoiceShow($conn,$bilID){
/*session_start();*/
$trantID=null;
$wID=null;
$elecID=null;
$elecBef=null;
$elecNow=null;
$elecUPrice=null;
$elecSignPrice=null;
$wBef=null;
$wNow=null;
$wUPrice=null;
$wSignPrice=null;
try{
$sql="select * from monthBill where ID=?";
$pdo2=$conn->prepare($sql);
$pdo2->execute([$bilID]);
if($pdo2->rowCount()>0){
$fullInfo2=$pdo2->fetchall();
	foreach($fullInfo2 as $info){
		$billNum=$info['ID'];
		$billDate=$info['dateIDU'];
		$elecNow=$info['elecCount'];
		$elecNow=$info['elecCount'];
		$elecID=$info['elecBillID'];
		$wNow=$info['waterCount'];
		$wID=$info['waterBillID'];
		$trantID=$info['trantID'];
	}
}
/*get trantName*/
if($trantID!=null){
$sql2="select * from users where ID=?";
$pdo3=$conn->prepare($sql2);
$pdo3->execute([$trantID]);
if($pdo3->rowCount()>0){
$fullInfo3=$pdo3->fetchall();
	foreach($fullInfo3 as $info3){
		$flatsNum=$info3['flatsNumber'];
		$trantName=$info3['name'];
		$flatsValue=$info3['faltsPrice'];
		
	}
}
}else{
	echo"<h4>
	للاسف لم يتم قطع فاتورة في هذا الشهر المحدد !
	يرجى مراجعة المشرف
	</h4><br>";
	exit();
}
/*get trantName*/	
/*get elecBef*/
if($elecID!=null){
$sql4="select * from elecbill where ID=?";
	$pdo4=$conn->prepare($sql4);
	$pdo4->execute([$elecID]);
		$fullInfo4=$pdo4->fetchall();
		
            foreach($fullInfo4 as $info4)
			{
				$elecUPrice=$info4['unitPrice'];
				$elecSignPrice=$info4['signPrice'];
			}
}
/*get elecBef*/
/* get water 5*/
if($wID!=null){
$sql5="select * from waterbill where ID=?";
	$pdo5=$conn->prepare($sql5);
	$pdo5->execute([$wID]);
		$fullInfo5=$pdo5->fetchall();
		
            foreach($fullInfo5 as $info5)
			{
				$wUPrice=$info5['wUnitPrice'];
				$wSignPrice=$info5['wSignPrice'];
			}
}
/* get water 5*/
/*before 6*/
if($trantID!=null){
require_once("config/ourFunctions.php");
$sql6="select * from monthbill where dateIDU=? and trantID=?";
				$pdo6=$conn->prepare($sql6);
				$pdo6->execute([getLastMonth(date("Y-m")),$trantID]);
				if($pdo6->rowCount()>0){
				$fullInfo6=$pdo6->fetchall();
				foreach($fullInfo6 as $info6){$elecBef=$info6['elecCount'];$wBef=$info6['waterCount'];}
				}else{$wBef=0;$elecBef=0;}
}
/*before 6*/
/* remaining 7*/
if($trantID!=null && $billNum!=null)
{
$remaining=CalculateRemaining($conn,$trantID,$billNum);
}
else{$remaining=0;}

	/* remaining 7*/
$elecTotal=(((Max($elecNow-$elecBef,0))*($elecUPrice))+$elecSignPrice);
	
$wTotla=((Max($wNow-$wBef,0))*($wUPrice))+$wSignPrice;
	
}catch(PDOException $x){echo $x->getMessage();}

?>
<!DOCTYPE html>
<html  lang="ar" xml:lang="ar">
	<head >
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />

		<title><?php echo $title?></title>
		<script src="js/html2pdf.bundle.js"></script>
		<style>
			body {
				font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
				text-align:right;
				color: #A64DE9;
			}

			body h1 {
				font-weight: 300;
				margin-bottom: 1px;
				padding-bottom: 1px;
				color: #C73EE5;
			}

			body h3 {
				font-weight: 300;
				margin-top: 10px;
				margin-bottom: 20px;
				font-style:normal;
				color: #C73EE5;
			}

			body a {
				color: #06f;
			}
			

			.invoice-box {
				max-width: 800px;
				margin: auto;
				padding: 20px;
				border: 1px solid #eee;
				box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
				font-size: 16px;
				line-height: 24px;
				font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
				color:black;
			}

			.invoice-box table {
				width: 100%;
				line-height:normal;
				text-align: right;
				border-collapse: collapse;
			}

			.invoice-box table td {
				padding: 5px;
				vertical-align: top;
			}

			.invoice-box table tr td:nth-child(2) {
				text-align: right;
			}

			.invoice-box table tr.top table td {
				padding-bottom: 12px;
			}

			.invoice-box table tr.top table td.title {
				font-size: 45px;
				line-height: 45px;
				color: #333;
			}

			.invoice-box table tr.information table td {
				padding-bottom: 40px;
			}

			.invoice-box table tr.heading td {
				background: #9829DC;;
				border-bottom: 1px solid black;
				color: white;
			}

			.invoice-box table tr.details td {
				border:1px solid hsla(283,68%,86%,1.00);
				background: hsla(0,9%,94%,0.92);
				
			}

			.invoice-box table tr.item td {
				
			}

			.invoice-box table tr.item.last td {
				border-bottom: none;
			}

			.invoice-box table tr.total td:nth-child(2) {
				border-top: 1px solid #eee;
				font-weight: bold;
			}

			@media only screen and (max-width: 600px) {
				.invoice-box table tr.top table td {
					width: 70%;
				}

				.invoice-box table tr.information table td {
					
				}
				
			}
			.clear{
					clear: both;
				}
		</style>
	</head>
<script>
jQuery('#invoiceConent2Print').slideDown();
jQuery('.container-Bill').slideUp();
function invoiceDownload(){
	
const elementID=document.getElementById("invoiceConent2Print");
	html2pdf()
	.from(elementID)
	.save();
//	document.getElementById("trantNameu").value+"فاتورة_"
}
	
</script>
<script>
$(document).ready(function() {
	
	var isMobile = {

Android: function() {

return navigator.userAgent.match(/Android/i);

},

BlackBerry: function() {

return navigator.userAgent.match(/BlackBerry/i);

},

iOS: function() {

return navigator.userAgent.match(/iPhone|iPad|iPod/i);

},

Opera: function() {

return navigator.userAgent.match(/Opera Mini/i);

},

Windows: function() {

return navigator.userAgent.match(/IEMobile/i);

},

any: function() {

return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows());

}

};

$(document).on("click", '.whatsapp', function() {


var text = $(this).attr("data-text");

var url = $(this).attr("data-link");

var message = encodeURIComponent(text) + " - " + encodeURIComponent(url);
alert(invoiceDownload());
var whatsapp_url = "whatsapp://send?text=" + message;

window.location.href = whatsapp_url;


});
});
</script>
	<body >
		
		<div id="invoiceConent2Print">
				<div class="invoice-box" >
			<table >
							<tr >
								<td style=" ">
									<font style="float:right;">
										<?php echo " رقم الشقة "." (".$flatsNum.") " ?></font>
									<font style="float:left;">
										<?php echo "فاتورة_رقم  $billNum " ?></font>
								</td>
								
							</tr>
						</table><hr>
			<div class="clear"></div>
			<table>
			
				<tr class="information" >
					<td colspan="4">
						
						<table style="text-align: center">
							<tr >
								<td> 
									<?php echo "اسم_المستأجر ".$trantName ?><br />
							
							<input type="text" value="<?php echo $trantName ?>" hidden id="trantNameu">
								</td>
							</tr>
							</table>
						
					</td>
				</tr>
				<tr class="heading">
					<td> </td>
					<td>فاتورة_الكهرباء </td>
					<td>فاتورة_الماء </td>
				
				</tr>

				<tr class="details">
					<td>القراءه_الحاليه</td>
					<td><?php echo $elecNow?></td>
					<td><?php echo $wNow?></td>
				</tr>
				<tr class="details">
					<td>القراءه_السابقة</td>
					<td><?php echo $elecBef?></td>
					<td><?php echo $wBef?></td>
					
				</tr>
				<tr class="details"><td>الوحدات_المستهلكة</td>
				<td><?php echo Max($elecNow-$elecBef,0)?></td>
				<td><?php echo Max($wNow-$wBef,0)?></td>
					
				</tr>
				</tr>
				<tr class="details">
					<td>سعر_الوحدة</td>
					<td><?php echo $elecUPrice?></td>
					<td><?php echo $wUPrice?></td>
				</tr>
				</tr>
				<tr class="details">
					<td>سعر_الاشتراك</td>
					<td><?php echo $elecSignPrice?></td>
					<td><?php echo $wSignPrice?></td>
				</tr>
				<tr class="details" style="background: hsla(295,21%,88%,0.80)">
					<td >الاجمالي</td>
					<td>
			<?php echo formatMoney($elecTotal,".")?>
					</td>
					<td>
			<?php echo formatMoney($wTotla,".");?>
					</td>
				</tr>
				<tr class="heading" style="text-align:center">
				<td colspan="1">
					ايجار_الشقة
				<?php echo formatMoney($flatsValue,".");
				 ?> 
				</td>
					<td></td>
				<td colspan="">
					المتأخرات
				<?php echo formatMoney($remaining,".");
				 ?> 
				</td>
				</tr>
		
		
			
			</table><br>
	
				<div class="total" style="text-align: right">
					<h5> 
					<?php echo "المطلوب من الاخ ".$trantName;?>
					</h5>
 					<h6>
						مبلغ_وقدرة
						<?php 
						$number=($wTotla+$elecTotal+$flatsValue+$remaining);
	
					echo "#".formatMoney( $number,".")."#";
						?>
					</h6>
				</div><hr>
				<font style="float:left;font-size: 12px">اصدرت_بواسطة
				<?php echo $_SESSION["userName"];?>
				</font>
			<p style="float:right;font-size: 12px">تاريخ_الاصدار
				<?php echo date("Y/m/d");?>
				</p>
		</div>
</div>
<div id="PrintBTN"><hr>
				<center><button class="btn btn-success "
								onclick="invoiceDownload()">
					sss
<!--					<a data-text="Your message goes here.." data-link="invoiceDownload()" class="">Share</a>-->
					</button></center>
</div>
	</body>
</html>
		
		

<?php
}

require_once("config/conn.php");
require_once("config/ourFunctions.php");
require_once("head.php");
invoiceShow($conn,'21049');
?>

