<?php

if(isset($_COOKIE["userName"])) {
	if(session_status() == PHP_SESSION_NONE){
    session_start();
}
$_SESSION["userName"]=$_COOKIE["userName"];
$_SESSION["userID"]=$_COOKIE["userID"];
$_SESSION["grant"]=$_COOKIE["grant"];
if($_SESSION["grant"]=="admin"){
	header("location: home.php");
	exit();
}else{
	header("location: userShow.php");
	exit();
}

} else {
	header("location: login.php");
	exit();
}
