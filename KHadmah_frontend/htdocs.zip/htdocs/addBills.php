<style>#loader-11 { width: 100%; height: 100%; z-index: 2; } #loader-11 #loader:first-child div { display: block; width: 100px; height: 100px; border: 3px solid #ddd; border-radius: 50%; position: absolute; top: 0; right: 0; bottom: 0; left: 0; margin: auto; } #loader-11 #loader:first-child>div>div { width: 90px; height: 90px; border: 5px solid #000; border-radius: 50%; margin: auto; overflow: hidden; } #loader-11 #loader:first-child div div div { width: 110px; height: 110px; margin: auto; top: 360px; background-color: #ddd; border-radius: 0%; border: none; -webkit-animation: anim 3s ease infinite alternate, color 4s ease infinite alternate; -moz-animation: anim 3s ease infinite alternate, color 4s ease infinite alternate; -o-animation: anim 3s ease infinite alternate, color 4s ease infinite alternate; animation: anim 3s ease infinite alternate, color 4s ease infinite alternate; } @-webkit-keyframes anim { 100% { top: 0 } } @-moz-keyframes anim { 100% { top: 0 } } @-o-keyframes anim { 100% { top: 0 } } @keyframes anim { 100% { top: 0 } } @-webkit-keyframes color { 0% { background-color: green; } 25% { background-color: green; } 50% { background-color: red; } 75% { background-color: yellow; } 100% { background-color: blue; } } @-moz-keyframes color { 0% { background-color: green; } 25% { background-color: green; } 50% { background-color: red; } 75% { background-color: yellow; } 100% { background-color: blue; } } @-o-keyframes color { 0% { background-color: green; } 25% { background-color: green; } 50% { background-color: red; } 75% { background-color: yellow; } 100% { background-color: blue; } } @keyframes color { 0% { background-color: green; } 25% { background-color: green; } 50% { background-color: red; } 75% { background-color: yellow; } 100% { background-color: blue; } } </style>
<div id="showLoader-11">
<div class="loader-wrapper" id="loader-11">
    <div id="loader">
        <div>
            <div>
                <div>
                </div>
            </div>
        </div>
    </div>
    </div>
</div>
<script>
    loaders = document.getElementsByClassName('loader-wrapper');
    loaders[0].style.display = "inline-block";

    function change(self) {
	
        for (var i = loaders.length - 1; i >= 0; i--) {
		
            loaders[i].style.display = "none";
        }
        id = self.id;
        loaders[id - 1].style.display = "inline-block";
    };
    </script>
<?php
require("head.php");
if(empty($_SESSION["userName"])){ echo"<script> location.replace('index.php'); </script>";}
else if($_SESSION["grant"]=="trant"){echo"<script> location.replace('userShow.php'); </script>";}

?>		
<div class="card divWelcomeUser">
	
		مرحباً: <?php echo $_SESSION['userName']; ?> 
		<a href='home.php'><span class='fa fa-home'></span></a>
	
</div>
<section class="flats-sectionTop card">
	<table>
		<tr>
				<label>
					
						<input type="number"id="flatsNumber" placeholder="رقم الشقه">
						
					
					<div class="label-text"> <i class="fa fa-home"></i>
						رقم الشقه</div>
				</label>
				<label>
					
					<div class="label-text">
						<h5 id="userFlatsName"></h5>
						<input id="userFlatsID" type="text" hidden>
						
						<input id="userID" type="text" hidden value=<?php echo $_SESSION["userID"]; ?>>
					
					</div>
				</label>
			
		</tr>
		<tr class="">
		<select id="showBillMonth" class="select-css">
				<option value="01">قطع فاتورة لشهر(1)</option>
				<option value="02">قطع فاتورة لشهر(2)</option>
				<option value="03">قطع فاتورة لشهر(3)</option>
				<option value="04">قطع فاتورة لشهر(4)</option>
				<option value="05">قطع فاتورة لشهر(5)</option>
				<option value="06">قطع فاتورة لشهر(6)</option>
				<option value="07">قطع فاتورة لشهر(7)</option>
				<option value="08">قطع فاتورة لشهر(8)</option>
				<option value="09">قطع فاتورة لشهر(9)</option>
				<option value="10">قطع فاتورة لشهر(10)</option>
				<option value="11">قطع فاتورة لشهر(11)</option>
				<option value="12">قطع فاتورة لشهر(12)</option>
			  </select>
			<br>
		</tr>
		<tr  >
			<div id="showDeleBill">
			<br>
			<br><hr>
				<h5 style='color:red;'>تم قطع فاتورة بنفس هذا الشهر !للشقة المحددة</h5><br>
				هل تريد حذف هذه الفاتورة!
			<button class="btn btn-warning" id="deleBill">  حذف <i class="fa fa-trash"></i></button>
			</div>
			
			
			
		</tr>
	</table>
</section>
<script>
$(".divWelcomeUser").slideDown();
function monthFormated(date) {
   if(!date)
     date = new Date();

     month = date.getMonth(); 
    return month < 9 ? "0" + (month+1) : month+1;
};
	$('#showBillMonth').val(monthFormated()).change();
	
	
	var e = document.getElementById("showBillMonth");
var month = e.value;
	
$("#deleBill").click(function(){
	$(document).ajaxSend(function() {
    $("#overlay").fadeIn(300);　
  });
	


	var dellBilDT=new FormData();
	dellBilDT.append('trantID',document.getElementById("userFlatsID").value);
	dellBilDT.append('billDate',jQuery("#showBillMonth").val());
	
    $.ajax({
      type: 'POST',
		contentType: false,
          processData: false,
		url: 'config/deleBillMonthConfig.php',
		data: dellBilDT,
      success: function(data){
        $("#userFlatsName").html(data);
      }
    }).done(function() {
      setTimeout(function(){
        $("#overlay").fadeOut(300);
      },500);
    });
	
});
function getFlatsTrant(){
	$(document).ajaxSend(function() {
    $("#overlay").fadeIn(300);　
  });
		
	var fltsNmberF=new FormData();
	fltsNmberF.append('flatsNumber',jQuery('#flatsNumber').val());
	fltsNmberF.append('billDate',jQuery("#showBillMonth").val());
	
    $.ajax({
      type: 'POST',
		contentType: false,
          processData: false,
		url: 'config/getUserFlatsName.php',
		data: fltsNmberF,
      success: function(data){
        $("#userFlatsName").html(data);
      }
    }).done(function() {
      setTimeout(function(){
        $("#overlay").fadeOut(300);
      },500);
    });
}
$("#showBillMonth").change(function(){getFlatsTrant();});
	
$("#flatsNumber").change(function(){getFlatsTrant();});/*end flatsNumber change--------------*/
</script>

<!------------------------------------------>
<div class="container-Bill">
<section class="elec-section card" style="margin-top:2%;background: #d913d994">
			<table>
				<center><h4><i class="glyphicon glyphicon-hom"></i>
					فاتورة الكهرباء
					
					</h4></center><hr>
				<tr >
					<td width="110px" > 
						القراءه الحاليه
					</td>
					
					<td colspan="4">
						
						<input type="number" id="elecCounterValueNow"  class="form-control" style="width:100%;">
					</td>
						
				</tr>
				<td colspan="4" ><hr></td>
				<tr>
				
					<td>
					<div class="label-text"> القراءه السابقه</div>
					</td>
					<td>
							<input type="number" id="elecBeforeCount"  class="form-control" readonly>
						<input type="number" id="elecBillID" hidden >
					</td>
					<td>	
						<div class="label-text"> سعر الوحده </div>
						</td>
						<td>
								<input type="number" id="elecUnitPrice" readonly class="form-control">
						</td>
				</tr>
			<tr>
				<td>	
						<div class="label-text"> سعر الاشتاراك  </div>
						</td>
						<td>
								<input type="number" id="elecSignPrice" readonly class="form-control">
						</td>
					<td > 
						الاجمالي
					</td>
					<td colspan="6">
						
						<input type="number" id="elecTotal"  class="form-control" style="width:100%;" readonly>
					</td>
						
				</tr>
			</table>
		</section>
<!------------------------water section----------------------->
<section class="water-section card" style="margin-top: 6%;background: #d913d945;">
	<table>
				<center><h4>فاتورة الماء</h4></center><hr>
				<tr >
					<td width="110px" > 
						القراءه الحاليه
					</td>
					
					<td colspan="4">
						
						<input type="number" id="wNowCount"  class="form-control" style="width:100%;">
					</td>
						
				</tr>
				<td colspan="4" ><hr></td>
				<tr>
				
					<td>
					<div class="label-text"> القراءه السابقه</div>
					</td>
					<td>
							<input type="number" id="wBeforeCount"  class="form-control" readonly>
						<input type="number" id="wBillID" readonly hidden >
					</td>
					<td>	
						<div class="label-text"> سعر الوحده </div>
						</td>
						<td>
								<input type="number" id="wUnitPrice" readonly  class="form-control">
						</td>
				</tr>
			<tr>
				<td>	
						<div class="label-text"> سعر الاشتراك </div>
						</td>
						<td>
								<input type="number" id="wSignPrice"  class="form-control" readonly>
						</td>
					<td > 
						الاجمالي
					</td>
					<td colspan="6">
						
						<input type="number" id="wTotal"  class="form-control" style="width:100%;" readonly>
					</td>
						
				</tr>
			</table>


</section>
<!------------------------------------->
<section class="month-section card" style="margin-top: 2%;margin-bottom:2%;background: #b417ca3d;">
<table>
				<center><h4>اجار شهري</h4></center><hr>
				<tr >
					<td  > 
						المبلغ
					</td>
					
					<td  width="100%">
						<input type="number" id="flatsPrice"  class="form-control" style="width:100%;">
						<input type="number" id="RealflatsPrice"  hidden>
					</td>
				</tr>
</table>

</section>
<!------------------------------------------------------>

<section class="card">
<table>
				<tr style="margin-bottom:12%;">
					<td > 
						اجمالي الفواتير
					</td>
					
					<td  width="100%">
						
						<input type="text" id="billTotal"  class="form-control" style="width:95%;" readonly>
					</td>
				</tr>
	
	
</table><hr>
	<table>
	<tr style="margin-bottom:12%;">
				
						اضافة ملاحظة على الفاتوره
					
					
					<td  width="100%">
						
						<input type="text" id="billNote"  class="form-control" max="398" style="width:100%;">
					</td>
				</tr>
	</table>

</section>
<section style="margin:4%;">
	
	<table style="width:100%;" >
		<tr>
			
			<td>
				<button id="exportBill" class="button" style="width:100%;"> حــــفظ   واصدار&#9679;<span class="fa fa-print"></span></button>
			</td>
		</tr>
		
	</table>
		

</section>
	
</div>


				

<script>
const formatter = new Intl.NumberFormat('ar', {
  style: 'currency',
  currency: 'YER',
  minimumFractionDigits: 2
});
/*count elec Total-------------------------------*/
function calculateTotal(nowCount,beforeCount,signPrice,unitPrice)	
{
return (((Math.max(0,Number(nowCount)-Number(beforeCount)))*(Number(unitPrice)))+Number(signPrice));
}

jQuery("#elecCounterValueNow").keyup(function(){
	var elecT=calculateTotal($("#elecCounterValueNow").val(),$("#elecBeforeCount").val(),
						$("#elecSignPrice").val(),
						$("#elecUnitPrice").val()				
						);
	var elecTotal=document.getElementById('elecTotal');
	elecTotal.value=elecT;
	billTotalCount();
});	
jQuery("#flatsPrice").keyup(function(){billTotalCount();});
/*count elec Total-------------------------------*/
/*count water Total-------------------------------*/
$("#wNowCount").keyup(function(){
	
	var wT=calculateTotal($("#wNowCount").val(),$("#wBeforeCount").val(),$("#wSignPrice").val(),$("#wUnitPrice").val());
	var wTotal=document.getElementById('wTotal');
	wTotal.value=wT;
	billTotalCount();

});	
/*count water Total-------------------------------*/

/*count all Total-------------------------------*/
	var countT=0;
function billTotalCount(){
	var billTotal=document.getElementById('billTotal');
	countT=Number(document.getElementById('elecTotal').value)+Number(document.getElementById('wTotal').value)+Number(document.getElementById('flatsPrice').value);
	billTotal.value=formatter.format(countT);}
	
	billTotalCount();
/*count all Total-------------------------------*/
/* function to send BillMonth by Ajax */
function sendMonthBill(){
	var flatNum=document.getElementById("flatsNumber").value;
	var elecNow=document.getElementById("elecCounterValueNow").value;
	var wNowCount=document.getElementById("wNowCount").value;
	var trantID=document.getElementById("userFlatsID").value;
	var userID=document.getElementById("userID").value;
	var elecBillID=document.getElementById("elecBillID").value;
	var wBillID=document.getElementById("wBillID").value;
	var flatsPrice=document.getElementById("flatsPrice").value;
	var RealflatsPrice=document.getElementById("RealflatsPrice").value;
	var monthDate=jQuery('#showBillMonth').val();
	  /*check validate-*/
	  if(flatNum==null || elecNow==null || wNowCount==null|| trantID==null|| userID==null|| wBillID==null || elecBillID==null){return false;}
	  else{
	  var addBill = new FormData();
		addBill.append('faltNum',flatNum);	
		addBill.append('elecNow',elecNow);	
		addBill.append('wNowCount',wNowCount);	
		addBill.append('trantID',trantID);	
		addBill.append('userID',userID);
		addBill.append('elecBillID',elecBillID);
		addBill.append('wBillID',wBillID);
		addBill.append('billTotal',countT);
		addBill.append('monthDate',monthDate);
		addBill.append('flatsPrice',flatsPrice);
		addBill.append('RealflatsPrice',RealflatsPrice);
		addBill.append('billNote',document.getElementById("billNote").value);
		addBill.append('elecTotal',document.getElementById("elecTotal").value);
		addBill.append('waTotal',document.getElementById("wTotal").value);
	jQuery.ajax({
      type: 'POST',
		contentType: false,
          processData: false,
			url: 'config/addBillConfig.php',
          data : addBill,
		success: function(data){
        $("#userFlatsName").html(data);
      },
    }).done(function() {
      setTimeout(function(){
        jQuery("#overlay").fadeOut(300);
      },500);
	  
	  }); /*end of ajax*/
	  }/*end of elese */
}
/* function to send BillMonth by Ajax */
jQuery(document).ajaxSend(function() {
    jQuery("#overlay").slideDown(300);　
  });
jQuery("#exportBill").click(function(){
	sendMonthBill();
  });/*end of addHose-------------------------*/
$(window).bind("load", function() {
	document.getElementById("loader-11").style.display ='none';
	
});
</script>
<?php
include("footer.php");