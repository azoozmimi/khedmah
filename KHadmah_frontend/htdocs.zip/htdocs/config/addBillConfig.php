<?php
if($_SERVER['REQUEST_METHOD']=="POST" &&
   $_POST["faltNum"]!=null &&
   $_POST["elecNow"]!=null &&
   $_POST["wNowCount"]!=null &&
   $_POST["trantID"]!=null &&
   $_POST["userID"]!=null &&
   $_POST["elecBillID"]!=null &&
   $_POST["monthDate"]!=null &&
   $_POST["flatsPrice"]!=null &&
   $_POST["RealflatsPrice"]!=null &&
   $_POST["wBillID"]!=null
  ){
	
	require_once("conn.php");
	require_once("ourFunctions.php");
	if( $_POST["flatsPrice"]!= $_POST["RealflatsPrice"]){
		$sql="update users set faltsPrice=? where ID=?";
		$pdo=$conn->prepare($sql);
		$pdo->execute([$_POST["flatsPrice"],$_POST["trantID"]]);
	}
	
	save_Bill($conn,$_POST["faltNum"],$_POST["elecNow"],
			  $_POST["wNowCount"],$_POST["trantID"],$_POST["userID"],
			  $_POST["elecBillID"],$_POST["wBillID"],$_POST["billTotal"],
        $_POST["monthDate"],$_POST["billNote"],$_POST["flatsPrice"],
        $_POST["elecTotal"],$_POST["waTotal"]);
	
	
}
else{
	echo"<h1 style='color:red'>هناك حقل فارغ</h1>";
}