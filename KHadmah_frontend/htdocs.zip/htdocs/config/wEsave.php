<?php
if($_SERVER['REQUEST_METHOD']=='POST' && 
  $_POST['elecPrice']!=null&&
  $_POST['elecValue']!=null&&
  $_POST['waterPrice']!=null&&
  $_POST['waterValue']!=null
  )
{
require_once("conn.php");
	try{
	$date=date("y_m");
	$sql="insert into elecbill(signPrice,unitPrice,dateAdded) values(?,?,?)";
	$pdo=$conn->prepare($sql);
	$pdo->execute([$_POST['elecValue'],$_POST['elecPrice'],$date]);
		
	$sql2="insert into waterbill(wSignPrice,wUnitPrice,wDateAdded) values(?,?,?)";
	$pdo2=$conn->prepare($sql2);
	$pdo2->execute([$_POST['waterValue'],$_POST['waterPrice'],$date]);
		echo"s";exit(); 
		}catch(PDOException $x){
		 echo $x->getMessage();
	}	
	
}
