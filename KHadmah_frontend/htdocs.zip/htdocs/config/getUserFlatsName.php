<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST'&&
	$_POST["flatsNumber"]!=null &&
	$_POST["flatsNumber"]!=""
   ){
	
	require("ourFunctions.php");
	include_once("conn.php");
	$flatsNum=$_POST["flatsNumber"];
	$sql="select * from users where flatsNumber=?";
	$pdo=$conn->prepare($sql);
	$pdo->execute([$flatsNum]);
	if($pdo->rowCount()>0){
		$fullInfo=$pdo->fetchall();
		$db_trantID;
		
            foreach($fullInfo as $info)
			{
				$db_fltsName=$info["name"];
				$db_fltsPrice=$info["faltsPrice"];
				$db_trantID=$info["ID"];
				
if($db_trantID!=null){
	echo $db_fltsName;
				
				echo"
				<script>
		jQuery('.container-Bill').slideDown();
			var _userFlatsID=document.getElementById('userFlatsID');
			_userFlatsID.value='$db_trantID';
			var flatsPrice=document.getElementById('flatsPrice');
			flatsPrice.value='$db_fltsPrice';
			
			var _RealflatsPrice=document.getElementById('RealflatsPrice');
			_RealflatsPrice.value='$db_fltsPrice';
			
		
			
			
		</script>
				";
$biilIDBefore;
$date=$_POST["billDate"];
if($date==01){
	$biilIDBefore=(date('y')-1).getLastMonth($date).$db_trantID;
}else{
	$biilIDBefore=date('y').getLastMonth($date).$db_trantID;
}
		
echo (getWaterBillInfo($conn,'wSignPrice','wUnitPrice','wBillID'));
echo (getElecBillInfo($conn,'elecSignPrice','elecUnitPrice','elecBillID'));
echo (getBeforMonthBill($conn,$biilIDBefore,'elecBeforeCount','wBeforeCount'));
	$ID=date("y").$_POST["billDate"].$db_trantID;
	$sql2="select * from monthbill where ID=?";
	$pdo2=$conn->prepare($sql2);
	$pdo2->execute([$ID]);
	if($pdo2->rowCount()>0){
		echo"
		<script>
		jQuery('.container-Bill').slideUp();
		jQuery('#showDeleBill').slideDown('slow');
		
		</script>
		";
	}else{
		echo"
		<script>
		jQuery('.container-Bill').slideDown();
		jQuery('#showDeleBill').slideUp('slow');
		
		</script>
		";
	}
	exit();
}}/*end foreach*/
	
	}else{
		echo"<h5 style='color:red;'>غير مسجلة هذه الشقة</h5>
		<script>
		jQuery('.container-Bill').slideUp();
		
		</script>
		";
	exit();
	}/*end else*/
}

