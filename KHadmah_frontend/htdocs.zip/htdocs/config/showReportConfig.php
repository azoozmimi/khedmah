<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST'&&
$_POST["month"]!=null &&
	$_POST["month"]!=""){
        $month=$_POST["month"];
      
require_once("conn.php");
require_once("ourFunctions.php");
try{
    setlocale(LC_MONETARY, 'en_US');
	$db_dagteID=0;
	$db_userID=0;
	$db_trantID=0;
	$db_flatPrice=0;
    $db_remainBefore=0;
    $db_FlatNumber=0;
    $showRemBefore="";
    $TabelBody="";
    $TabelHead;
    $totalFlatPric=0;
    $db_bushCash=0;
    $db_bushNote="";
    $db_bushUser="";
    $db_bushUserID=0;
    $tableBushCashHead="";
    $tableBushCashBody="";
    $totalBushCash=0;
    $tableChargeHead="";
    $db_chargeNote="";
    $db_chargNumber=0;
    $chargeBody="";
    $numberOfCharge=0;
    $dateGetCash=date("Y")."_".$month;
	$sql2="select * from monthbill where dateIDU=?;";
	$pdo2=$conn->prepare($sql2);
	$pdo2->execute([$month]);
    if($pdo2->rowCount()>0)
    {
        $TabelHead="
        <div class='panel panel-default'>
        <div class='panel-heading'>
           تقرير شهر $month
        </div>
        <table class='table'>
          <thead>
          <tr>
          <th>الشقة رقم</th>
          <th>قيمة ايجارها</th>
          <th>تم سداد ايجارها</th>
          </tr>
          </thead>
       </tbody>
        ";
		$fullInfo2=$pdo2->fetchall();
	
      foreach($fullInfo2 as $info2)
			{
                $db_dagteID=$info2['dateIDU'];
                $db_userID=$info2['userID'];
                $db_trantID=$info2['trantID'];
                $db_flatPrice=$info2['flatPrice'];
                $totalFlatPric+=$info2['flatPrice'];
                $db_remainBefore=$info2['remBefore'];
    $sql="select * from users where ID=?;";
	$pdo=$conn->prepare($sql);
	$pdo->execute([$db_trantID]);
		$fullInfo=$pdo->fetchall();
		
      foreach($fullInfo as $info)
			{
				$db_FlatNumber=$info['flatsNumber'];
			}
/*-------------------------------------------get if baying---------------------------------*/
$sql4="select * from trantbaying where $db_trantID=? and date=?;";
$dateTrant=date("Y")."-".$month;
$pdo4=$conn->prepare($sql4);
$pdo4->execute([$db_trantID,$dateTrant]);
            if($pdo4->rowCount()>0) {$showRemBefore="<i class='fa fa-check' style='color:green'></i>"; }
            else{ $showRemBefore="<i class='fa fa-times' style='color:red'></i>"; }
           $TabelBody.="
    
  <tr>
  <td>$db_FlatNumber</td>
  <td>$db_flatPrice</td>
  <td>$showRemBefore</td>
  </tr> ";
        }
        $TabelBody.="</tbody></table></div>";

       if($totalFlatPric>0)
      {
      $sql3="select * from bushcash where date=?;";
      $pdo3=$conn->prepare($sql3);
      $pdo3->execute([$dateGetCash]);
     $tableBushCashHead="
     <div class='panel panel-default'>
        <div class='panel-heading'>
          المصروفات
        </div>
        <table class='table'>
          <thead>
          <tr>
          <th>القيمة</th>
          <th>بواسطة</th>
          <th>ملاحظات </th>
          </tr>
          </thead>
       <tbody>
        ";
        $fullInfo3=$pdo3->fetchall();
	
        foreach($fullInfo3 as $info3)
              {
                  $db_bushCash=$info3["value"];
                  $totalBushCash+=$info3["value"];
                  $db_bushNote=$info3["note"];
                  $db_bushUserID=$info3["userID"];
   $sql="select * from users where ID=?;";
	$pdo=$conn->prepare($sql);
	$pdo->execute([$db_bushUserID]);
		$fullInfo=$pdo->fetchall();
		
      foreach($fullInfo as $info)
			{
				$db_bushUser=$info['name'];
			}
            $tableBushCashBody.="
  <tr>
  <td>$db_bushCash</td>
  <td>$db_bushUser</td>
  <td>$db_bushNote</td>
  </tr> ";
              }
    

      }
      $count= formatMoney(($totalFlatPric-$totalBushCash));
      $totalFlatPric=formatMoney($totalFlatPric);
      $totalBushCash=formatMoney($totalBushCash);

      if($totalFlatPric>0)
      {
      $sql6="select * from chargemoney where date=?;";
      $pdo6=$conn->prepare($sql6);
      $pdo6->execute([$dateGetCash]);
     $tableChargeHead="<hr>
     <div class='panel panel-default'>
        <div class='panel-heading'>
          الايداع
        </div>
        <table class='table'>
          <thead>
          <tr>
          <th>رقم الايداع</th>
          <th>ملاحظات </th>
          </tr>
          </thead>
       <tbody>
        ";
        
        $fullInfo6=$pdo6->fetchall();
	
        foreach($fullInfo6 as $info3)
              {
                  $db_chargNumber=$info3["numberOfCharge"];
                  $db_chargeNote=$info3["note"];
            $chargeBody.="
  <tr>
  <td>$db_chargNumber</td>
  <td>$db_chargeNote</td>
  </tr> ";
              }
    
            }
        echo $TabelHead.$TabelBody.$tableBushCashHead.$tableBushCashBody."</tbody></table></div>
        <table>
        <tr>
        <th>اجمالي الايجار = </th>
        <td>$totalFlatPric</td>
      </tr>
      <tr>
        <th>اجمالي المصروفات = </th>
        <td>$totalBushCash</td>
      </tr>
      <hr>
      <tr>
        <th>متبقي لكم= </th>
        <td>$count</td>
      </tr>
      </table>".$tableChargeHead.$chargeBody."</tbody></table></div><br><br>";
}else{
    echo"
    <h3>لم يتم بعد قطع فواتير لهذا الشهر !... </h3><br><br>
    ";
}
			
}catch(PDOException $x){echo $x->getMessage();}
    }
?>

