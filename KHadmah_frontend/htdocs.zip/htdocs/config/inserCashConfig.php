<?php
if($_SERVER['REQUEST_METHOD'] =='POST'&&
   $_POST["trantID"]!=null&&
   $_POST["baying"]!=null&&
   $_POST["baying"]!=0 &&
   $_POST["userID"]!=null
  )
{

try{
	require("conn.php");
	$trantID=$_POST["trantID"];
	$userID=$_POST["userID"];
	$baying=$_POST["baying"];
	$date=date("Y")."-".$_POST['bayingDate'];	   
	$sqlInsert="insert into trantbaying values(?,?,?,?)";
		$pdo2=$conn->prepare($sqlInsert);
		$pdo2->execute([$trantID,$userID,$baying,$date]);
		echo"تم اضافة البلغ لحساب المستأجر";
	echo"
	<script>
	$(':input').val('');
	document.getElementById('reTotal').innerHTML=''
	</script>
	";
}catch(PDOException $ex){echo $ex->getMessage();
							echo"<h5 style='color:red;'> هناك خطاء في ادحال البيانات</h5>";}	
	
}else{
	echo"<h5 style='color:red;'> هناك خطاء في ادحال البيانات</h5>";
}
