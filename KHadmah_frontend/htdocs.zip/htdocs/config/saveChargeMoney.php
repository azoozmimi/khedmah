<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST'&&
$_POST["chargeID"]!=null){
        $month=date("Y")."_".$_POST['chargeDate'];
require_once("conn.php");
try{
    $chargeID=$_POST["chargeID"];
    $chargeNote=$_POST["chargeNote"];
    $userID=$_POST['userID'];
    $sql3="insert into `chargemoney`(`date`, `numberOfCharge`, `note`) values(?,?,?)";
    $pdo3=$conn->prepare($sql3);
    $pdo3->execute([$month,$chargeID,$chargeNote]);
    echo"<h1>تم الحفظ</h1> ";

}catch(PDOException $x){echo $x->getMessage();}
}