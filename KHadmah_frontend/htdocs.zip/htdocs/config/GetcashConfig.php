<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST'&&
	$_POST["flatsNumber"]!=null &&
	$_POST["flatsNumber"]!=""
   ){
	require_once("ourFunctions.php");
	include_once("conn.php");
	$sql="select * from users where flatsNumber=?";
	$pdo=$conn->prepare($sql);
	$flatsNum=$_POST["flatsNumber"];
	$pdo->execute([$flatsNum]);
	if($pdo->rowCount()>0){
		$fullInfo=$pdo->fetchall();
		$db_trantID;
		
            foreach($fullInfo as $info)
			{
				$db_fltsName=$info["name"];
				$db_fltsPrice=$info["faltsPrice"];
				$db_trantID=$info["ID"];
				echo $db_fltsName;
				$remaining=CalculateRemaining($conn,$db_trantID,null);
				
				$x=formatMoney($remaining,true);
				
				echo"
				<script>
			var userFlatsID=document.getElementById('userFlatsID');
			userFlatsID.value=$db_trantID;
			document.getElementById('reTotal').innerHTML='$x';
			
		jQuery('.container-Bill').slideDown();
		</script>
				";
				
			}/*end foreach*/
		
		
	}else{
		echo"<h5 style='color:red;'>غير مسجلة هذه الشقة</h5>
		<script>
		jQuery('.container-Bill').slideUp();
		
		</script>
		";
	
	}/*end else*/
}else{
		echo"<h5 style='color:red;'>خطاء في الادخال</h5>
		<script>
		jQuery('.container-Bill').slideUp();
		
		</script>
		";
	
	}/*end else*/

