<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST'&&
$_POST["month"]!=null &&
	$_POST["month"]!=""){
        $month=$_POST["month"];
      
require_once("conn.php");
require_once("ourFunctions.php");
try{

	$db_trantID=0;

    $db_FlatNumber=0;
    $TabelBody="";
    $TabelHead;
    $totalFlatPric=0;
    $countElec=0;
    $countWa=0;
    $totalWa=0;
    $totalElec=0;
    $DateM=$month."_".date("y");

	$sql2="select * from monthbill where dateIDU=?;";
	$pdo2=$conn->prepare($sql2);
	$pdo2->execute([$month]);
    if($pdo2->rowCount()>0)
    {
        

        $TabelHead="
        <div class='panel panel-default'>
        <div class='panel-heading'>
           تقرير شهر $month
        </div>
        <table class='table'>
          <thead>
          <tr>
          <th>الشقة رقم</th>
          <th>اجمالي الماء</th>
          <th>اجمالي الكهرباء</th>
          </tr>
          </thead>
       </tbody>
        ";
		$fullInfo2=$pdo2->fetchall();
	
      foreach($fullInfo2 as $info2)
			{
                $db_trantID=$info2['trantID'];
            
                $db_dateIDU=$info2['ID'];
               $db_elecID=$info2['elecBillID'];
               $db_waID=$info2['waterBillID'];
               $countWa=$info2['waTotal'];
               $countElec=$info2['elecTotal'];
                $sql="select * from users where ID=?;";
                $pdo=$conn->prepare($sql);
                $pdo->execute([$db_trantID]);
                    $fullInfo=$pdo->fetchall();
                    
                  foreach($fullInfo as $info)
                        {
                            $db_FlatNumber=$info['flatsNumber'];
                        }
            /*-------------------------------------------get if baying---------------------------------*/
            $sql4="select * from trantbaying where $db_trantID=? and date=?;";
            $dateTrant=date("Y")."-".$month;
            $pdo4=$conn->prepare($sql4);
            $pdo4->execute([$db_trantID,$dateTrant]);
            $totalWa+=$countWa;
            $totalElec+=$countElec;
         
                       $TabelBody.="
                
              <tr>
              <td>$db_FlatNumber</td>
              <td> $countWa</td>
              <td>$countElec</td>
              </tr> ";
                    }
                    $totalWa=formatMoney($totalWa);
                    $totalElec=formatMoney($totalElec);
                    $TabelBody.="</tbody></table></div>
                    <table class='table'>
                    <tr>
                    <th>  اجمالي الماء  </th>
                    <td> $totalWa </td>
                    </tr>
                    <tr>
                    <th>  اجمالي الكهرباء  </th>
                    <td>  $totalElec </td>
                    </tr>
                   
                    </table>
                    ";
            

        echo $TabelHead.$TabelBody;
}else{
    echo"
    <h3>لم يتم بعد قطع فواتير لهذا الشهر !... </h3><br><br>
    ";
}
			
}catch(PDOException $x){echo $x->getMessage();}
    }
?>

