<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST'&&
$_POST["bushValue"]!=null){
        $month=date("Y")."_".$_POST['ExchangeDate'];
require_once("conn.php");
try{
    $value=$_POST["bushValue"];
    $note=$_POST["bushNote"];
    $userID=$_POST['userID'];
    $sql3="insert into `bushcash`(`value`, `note`, `userID`, `date`) values(?,?,?,?)";
    $pdo3=$conn->prepare($sql3);
    $pdo3->execute([$value,$note,$userID,$month]);
    echo"<h1>تم الحفظ</h1>";

}catch(PDOException $x){echo $x->getMessage();}
}