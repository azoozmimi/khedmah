<?php
if($_SERVER["REQUEST_METHOD"]=="POST" &&
  $_POST["month"]!=null
  &&
  $_POST["trantID"]!=null){
	session_start();
require_once("conn.php");
require_once("../invoiceShow.php");
	$month=$_POST["month"];
	$trantID=$_POST["trantID"];
	$ID=date("y")."$month".$trantID;
	invoiceShow($conn,$ID);
}				

		