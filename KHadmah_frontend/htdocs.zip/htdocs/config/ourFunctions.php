<?php

function getWaterBillInfo($conn,$wSignPriceInput,$wUnitPriceInput,$wBillID){
	
	try{
	$db_wSignPrice;
	$db_wUnitPrice;
	$db_wBillID;
	$sql2="select * from waterbill ORDER BY ID DESC LIMIT 1;";
	$pdo2=$conn->prepare($sql2);
	$pdo2->execute();
	$fullInfo2=$pdo2->fetchall();
		
            foreach($fullInfo2 as $info)
			{
				$db_wUnitPrice=$info['wUnitPrice'];
				$db_wSignPrice=$info['wSignPrice'];
				$db_wBillID=$info['ID'];
			}
		 
   	
	echo"
	<script>
		var _wSignPrice=document.getElementById('$wSignPriceInput');
		_wSignPrice.value=$db_wSignPrice;
		var _wUnitPrice=document.getElementById('$wUnitPriceInput');
		_wUnitPrice.value=$db_wUnitPrice;
		var _wBillID=document.getElementById('$wBillID');
		_wBillID.value=$db_wBillID;
	</script>
	";
	}catch(PDOException $x){
		 echo $x->getMessage();
	}
}
/*end getWaterBillInfo function..................*/
function getElecBillInfo($conn,$elecSignPriceInput,$elecUnitPriceInput,$elecBillID){
	
	try{
	$db_elecSignPrice;
	$db_elecUnitPrice;
	$db_elecBillID;
	$sql2="select * from elecbill ORDER BY ID DESC LIMIT 1;";
	$pdo2=$conn->prepare($sql2);
	$pdo2->execute();
		$fullInfo2=$pdo2->fetchall();
		
            foreach($fullInfo2 as $info)
			{
				$db_elecUnitPrice=$info['unitPrice'];
				$db_elecSignPrice=$info['signPrice'];
				$db_elecBillID=$info['ID'];
			}
		 
   	
	echo"
	<script>
		var _elecSignPrice=document.getElementById('$elecSignPriceInput');
		_elecSignPrice.value=$db_elecSignPrice;
		var _elecUnitPrice=document.getElementById('$elecUnitPriceInput');
		_elecUnitPrice.value=$db_elecUnitPrice;
		var _elecBillID=document.getElementById('$elecBillID');
		_elecBillID.value=$db_elecBillID;
	</script>
	";
	}catch(PDOException $x){
		 echo $x->getMessage();
	}
}
/*end getWaterBillInfo function..................*/

function getBeforMonthBill($conn,$billID,$elecCount,$waterCount){

	try{
		$db_elecCount=0;
		$db_waterCount=0;
		$sql2="select * from monthbill where ID=?";
				$pdo2=$conn->prepare($sql2);
				$pdo2->execute([$billID]);
				$db_elecCount;
				$db_waterCount;
				if($pdo2->rowCount()>0){
				$fullInfo2=$pdo2->fetchall();
				foreach($fullInfo2 as $info2){$db_elecCount=$info2['elecCount'];$db_waterCount=$info2['waterCount'];}}/*end of if ------------*/
echo"
	<script>
		var waterCount=document.getElementById('$waterCount');
		waterCount.value=$db_waterCount;
		
		var _elecCount=document.getElementById('$elecCount');
		_elecCount.value=$db_elecCount;
	</script>
	";

	}catch(PDOException $x){
		 echo $x->getMessage();
	}
}/*end of getBeforeMonthBill---------------------------*/

function getLastMonth($d) {
 if($d==1)
{
$lastmonth=12;
}
else
{
$lastmonth=$d-1;
}
if($lastmonth >=1 && $lastmonth <10)
	return '0'.$lastmonth;
	else
		return($lastmonth);
}

/*fun to insert or update trantBaying*/
function CalculateRemaining($conn,$trantID,$dateB){
	try{
		
		$sql="SELECT * FROM  trantbaying WHERE tranID=?";
		$pdo=$conn->prepare($sql);
		$pdo->execute([$trantID]);
		$fullInfo=$pdo->fetchall();
		$db_baying=0;
			foreach($fullInfo as $info )
			{
				$db_baying+=$info['baying'];
			}
		
		if($dateB!=null){
		$sqlTest="SELECT * FROM  checkbill WHERE trantID=? and monthBillID=?";
		$pdo2=$conn->prepare($sqlTest);
		$pdo2->execute([$trantID,$dateB]);
		}
		else{
		$sqlTest="SELECT * FROM  checkbill WHERE trantID=?";
		
		$pdo2=$conn->prepare($sqlTest);
		$pdo2->execute([$trantID]);
		}
			$fullInfo2=$pdo2->fetchall();
			$db_remaining=0;
			foreach($fullInfo2 as $info )
			{
			$db_remaining+=$info['remaining'];
			}
		return($db_remaining-$db_baying);
		
	}catch(PDOException $x){echo $x->getMessage(); }
	
} 


/*fun to insert or update trantBaying*/
/*this fun to save a bill of month into a db*/
function save_Bill($conn,$flatNum,$elecNow,$wNowCount,$trantID,$userID,$elecBillID,$wBillID,$TotalBill,$monthDate,$billNote,$flatPrice,$elecTotal,$waTotal){
	
	try{
		$remBefore=max(0,CalculateRemaining($conn,$trantID,null));
		$sqlInsert="insert into monthbill values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
		$pdo2=$conn->prepare($sqlInsert);
			$IDUn=(date('y')."$monthDate".$trantID);
			$pdo2->execute([$IDUn,$monthDate,$elecNow,$elecBillID,$wNowCount,$wBillID,
							$userID,$trantID,$billNote,$flatPrice,$remBefore,$elecTotal,$waTotal]);
		$sqlInsertCheckBill="insert into checkbill(`userID`,`trantID`,`monthBillID`,`baying`,`remaining`) values(?,?,?,?,?)";
		$pdo2=$conn->prepare($sqlInsertCheckBill);
		$pdo2->execute([$userID,$trantID,$IDUn,0,$TotalBill]);
		echo"تم تقييد الفتورة الشهريه على حساب المستأجر";
		require("../invoiceShow.php");
		invoiceShow($conn,$IDUn);
	
		
	}catch(PDOException $x){echo $x;}
	
}/*end fun to save biil into db*/
/*insert into trantBaying fun*/

/*insert into trantBaying fun*/
/*format Mony.......*/
function formatMoney($number, $fractional=false) {
    if ($fractional) {
        $number = sprintf('%.2f', $number);
    }
    while (true) {
        $replaced = preg_replace('/(-?\d+)(\d\d\d)/', '$1,$2', $number);
        if ($replaced != $number) {
            $number = $replaced;
        } else {
            break;
        }
    }
    return $number;
}
/*format Mony.......*/