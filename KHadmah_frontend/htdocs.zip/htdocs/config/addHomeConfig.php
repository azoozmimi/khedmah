<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST'&&
	$_POST["hoseNumber"]!=null &&
	$_POST["hoseName"]!=null &&
	$_POST["hosePhone"]!=null &&
	$_POST["hosePass"]!=null &&
	$_POST["hosePrice"]!="NaN" &&
	$_POST["hosePrice"]!="0" &&
	$_POST["hosePrice"]!="" &&
	$_POST["grant"]!="" &&
	$_POST["hosePrice"]!=null)
{
require_once("conn.php");
	$hNumber=$_POST["hoseNumber"];
	$hName=$_POST["hoseName"];
	$hPhone=$_POST["hosePhone"];
	$hPass=$_POST["hosePass"];
	$hPrice=$_POST["hosePrice"];
	$hGrant=$_POST["grant"];
	try{
 $sql="insert into users(`name`, `flatsNumber`, `password`, `phone`, `faltsPrice`, `grant`)
 values(?,?,?,?,?,?)";
$pdo=$conn->prepare($sql);
$test=$pdo->execute([$hName,$hNumber,$hPass,$hPhone,$hPrice,$hGrant]);
if($test==true){
	echo"t";
	exit();	
}
	}catch(PDOException $x){
		echo"هناك خطاء في البيانات الرجاء التأكد من عدم مطابقتها ببينات اخرى";
        echo $x->getMessage();
		exit();
    }
	
}/*end of server requist----------------*/
