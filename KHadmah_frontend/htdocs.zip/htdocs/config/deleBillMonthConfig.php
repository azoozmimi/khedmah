<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST'&&
	$_POST["trantID"]!=null &&
	$_POST["billDate"]!=null &&
	$_POST["trantID"]!=""
   ){
	try{
		include_once("conn.php");
	$trantID=$_POST["trantID"];
	$month=$_POST["billDate"];
	$ID=date("y")."$month"."$trantID";
	$sql="DELETE FROM checkbill WHERE monthBillID=?";
	$pdo=$conn->prepare($sql);
	$pdo->execute([$ID]);
	$sql2="DELETE FROM monthbill WHERE ID=?";
	$pdo2=$conn->prepare($sql2);
	$pdo2->execute([$ID]);
		echo"
		<script>
		jQuery('.container-Bill').slideDown('slow');
		jQuery('#showDeleBill').slideUp('slow');
		
		</script>
		";
		
	}catch(PDOException $ex){
		echo $ex->getMessage();
	}
	
	
}