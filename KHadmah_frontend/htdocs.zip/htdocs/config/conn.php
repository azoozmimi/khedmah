<?php
define('DSN',"mysql:host=sql208.epizy.com;dbname=epiz_28438748_homebills;charset=utf8");
define("user","epiz_28438748");
define("pass","zucw7cm6BTHwN");
$opst=array(PDO::MYSQL_ATTR_INIT_COMMAND=>"SET NAMES utf8");

try{
 $conn=new PDO(DSN,user,pass,$opst);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $x){
    exit($x->getMessage());
}
