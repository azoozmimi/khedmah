<?php
require_once("head.php");
if(empty($_SESSION["userName"])){ echo"<script> location.replace('index.php'); </script>";}
else if($_SESSION["grant"]=="trant"){echo"<script> location.replace('userShow.php'); </script>";}
require_once("config/conn.php");

?>

<center class="card " style="font-size:30px">
مرحباً: <?php echo $_SESSION['userName']; ?> 
  <a href='home.php'><span class='fa fa-home'></span></a>

</center><br>

<section class="flats-sectionTop card">
		<select id="showBillMonth" class="select-css">
				<option value="01">صرفيات لشهر(1)</option>
				<option value="02">صرفيات لشهر(2)</option>
				<option value="03">صرفيات لشهر(3)</option>
				<option value="04">صرفيات لشهر(4)</option>
				<option value="05">صرفيات لشهر(5)</option>
				<option value="06">صرفيات لشهر(6)</option>
				<option value="07">صرفيات لشهر(7)</option>
				<option value="08">صرفيات لشهر(8)</option>
				<option value="09">صرفيات لشهر(9)</option>
				<option value="10">صرفيات لشهر(10)</option>
				<option value="11">صرفيات لشهر(11)</option>
				<option value="12">صرفيات لشهر(12)</option>
			  </select>

</section>
<script>
$(".divWelcomeUser").slideDown();
$(".loader-wrapper").slideUp();
$("#loader-11").slideUp();
function monthFormated(date) {
   if(!date)
     date = new Date();

     month = date.getMonth(); 
    return month < 9 ? "0" + (month+1) : month+1;
};
	$('#showBillMonth').val(monthFormated()).change();
	var e = document.getElementById("showBillMonth");
var month = e.value;

</script>

<!------------------------------------------>
<div class="container-Bill">
<section class="elec-section card" style="margin-top:2%;background: ">
  
<label for="basic-url"></label>
     
        <div class="input-group">
        <span class="input-group-addon" id="basic-addon3">المبلغ المصروف</span>
        <input type="number" min="0" class="form-control" id="bushValue" >
        </div>

        <div class="jumbotron">
          <h4> ملاحظات</h4>
        <textarea class="form-control" id="bushNote" aria-describedby="basic-addon3"></textarea>
<input type="hidden" value="<?php echo $_SESSION['userID'];?>" id="userID">
    </div>
<center>
<button class="btn btn-success" id="saveBushCash">حفظ</button><br>
</center>
<div id="userFlatsName"></div>
		</section>
</div>
<!------------------------------------------>
<?php
include("footer.php");
?>
<script>
jQuery(function($){
$(document).ajaxSend(function() {
    $("#overlay").fadeIn(300);　
  });
$("#saveBushCash").click(function(){

	
	if($("#bushValue").val()!=null){
      	
	var sendCashData=new FormData();
	sendCashData.append('bushValue',jQuery('#bushValue').val());
 sendCashData.append('bushNote',jQuery('#bushNote').val());
 sendCashData.append('userID',jQuery('#userID').val());
 sendCashData.append('ExchangeDate',jQuery('#showBillMonth').val());
    $.ajax({
      type: 'POST',
		contentType: false,
          processData: false,
		url: 'config/saveBushCash.php',
		data: sendCashData,
      success: function(data){
        $("#userFlatsName").html(data);
  
      }
    }).done(function() {
      setTimeout(function(){
        $("#overlay").fadeOut(300);
      },500);
    });
	}
});
/*end of send fun*/
});
</script>