<?php
require_once("head.php");
if(empty($_SESSION["userName"])){ echo"<script> location.replace('index.php'); </script>";}
else if($_SESSION["grant"]=="trant"){echo"<script> location.replace('userShow.php'); </script>";}
require_once("config/conn.php");

?>

<center class="card " style="font-size:30px">
مرحباً: <?php echo $_SESSION['userName']; ?> 
  <a href='home.php'><span class='fa fa-home'></span></a>

 
</center><br>

<center id="ContainerShow" style='display:none'>

 		 	<div class="labelImageContainer " style=" margin:2%;">
				
				<select id="showBillMonth" class="labelImageButton" style='color:yellow'>
				<option value="null" selected>اضغط...لعرض التقرير بحسب الشهر</option>
				<option value="01">عرض تقرير بحسب شهر(1)</option>
				<option value="02">عرض تقرير بحسب شهر(2)</option>
				<option value="03">عرض تقرير بحسب شهر(3)</option>
				<option value="04">عرض تقرير بحسب شهر(4)</option>
				<option value="05">عرض تقرير بحسب شهر(5)</option>
				<option value="06">عرض تقرير بحسب شهر(6)</option>
				<option value="07">عرض تقرير بحسب شهر(7)</option>
				<option value="08">عرض تقرير بحسب شهر(8)</option>
				<option value="09">عرض تقرير بحسب شهر(9)</option>
				<option value="10">عرض تقرير بحسب شهر(10)</option>
				<option value="11">عرض تقرير بحسب شهر(11)</option>
				<option value="12">عرض تقرير بحسب شهر(12)</option>
			  </select>
				
 	 			</div>
				<div id="showBillUser" class="labelImageContainer">
					
					
				</div>
				</center>	



</table>

</div>
        

<script>

jQuery(function($){
	$("#loader-11").fadeOut();
	$("#ContainerShow").fadeIn();
	 $("#showBillUser").html('يرجى احتيار الشهر ');
		  $("#showBillUser").append($("#loader-11").fadeIn());
jQuery(".divWelcomeUser").slideDown("slow");
jQuery(document).ajaxSend(function() {
    jQuery("#overlay").slideDown(300);　
  });
  $('#showBillMonth').click(function(){$('#showBillMonth').css("color","white")});
function monthFormated(date) {
   if(!date)
     date = new Date();

     month = date.getMonth(); 
    return month < 9 ? "0" + (month) : month+1;
}	
$("#showBillMonth").change(function(){
	var e = document.getElementById("showBillMonth");
var month = e.value;

if(month!='null'){
	var monthSendData=new FormData();
	monthSendData.append('month',jQuery("#showBillMonth").val());
	
	$.ajax({
      type: 'POST',
		contentType: false,
          processData: false,
		url:"config/showReportConfig.php",
		data: monthSendData,
      success: function(data){
        $("#showBillUser").html(data);
      
      }
    }).done(function() {
      setTimeout(function(){
        $("#overlay").fadeOut(300);
      },500);
    });
	}else{
		
		 $("#showBillUser").html('يرجى احتيار الشهر ');
		  $("#showBillUser").append($("#loader-11").fadeIn());
	}
/*end of send fun*/


	
});
});/*end doc fun*/
</script>
