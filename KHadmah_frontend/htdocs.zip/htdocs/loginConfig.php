<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST'&&
   $_POST["name"]!==null&& $_POST["pass"]!=null){
	try{
		
	$name=$_POST["name"];
	$pass=$_POST["pass"];
/*--------------------------------------------*/
require_once("config/conn.php");
	$sql="select *from users ";
$pdo=$conn->prepare($sql);
$pdo->execute();
$fullInfo=$pdo->fetchall();
		
            foreach($fullInfo as $info)
            {
                $db_name=$info['name'];
                $db_ID=$info['ID'];
				$db_pass=$info['password'];
				$db_flatsNumber=$info['flatsNumber'];
				$db_grant=$info['grant'];
				if(($db_name=="$name"|| $db_flatsNumber=="$name")  && $db_pass=="$pass")
				{
					session_start();
					$_SESSION["userName"]=$db_name;
					$_SESSION["userID"]=$db_ID;
					$_SESSION["grant"]=$db_grant;
					setcookie("userName",$_SESSION["userName"],time()+31556926 ,'/');
					setcookie("userID",$_SESSION["userID"],time()+31556926 ,'/');
					setcookie("grant",$_SESSION["grant"],time()+31556926 ,'/');
					/*setcookie()*/
					
				
					if($db_grant=="admin"){
					echo"a";
						exit();
					}
						
					else{
   					echo"u";
						exit();
					}
						
			
				}
            }/*end foreach*/
		echo"!";
	
	}catch(PDOException $x){echo $x->getMessage();}
}else{echo"error";}
	/*end post server*/
