<?php
require_once("head.php");
if(empty($_SESSION["userName"])){ echo"<script> location.replace('index.php'); </script>";}
else if($_SESSION["grant"]=="trant"){echo"<script> location.replace('userShow.php'); </script>";}
require_once("config/conn.php");

?>

<center class="card " style="font-size:30px">
مرحباً: <?php echo $_SESSION['userName']; ?> 
  <a href='home.php'><span class='fa fa-home'></span></a>

</center><br>

<section class="flats-sectionTop card">
		<select id="showBillMonth" class="select-css">
				<option value="01">ايداع  لشهر(1)</option>
				<option value="02">ايداع  لشهر(2)</option>
				<option value="03">ايداع  لشهر(3)</option>
				<option value="04">ايداع  لشهر(4)</option>
				<option value="05">ايداع  لشهر(5)</option>
				<option value="06">ايداع  لشهر(6)</option>
				<option value="07">ايداع  لشهر(7)</option>
				<option value="08">ايداع  لشهر(8)</option>
				<option value="09">ايداع  لشهر(9)</option>
				<option value="10">ايداع  لشهر(10)</option>
				<option value="11">ايداع  لشهر(11)</option>
				<option value="12">ايداع  لشهر(12)</option>
			  </select>

</section>
<script>
$(".divWelcomeUser").slideDown();
$(".loader-wrapper").slideUp();
$("#loader-11").slideUp();
function monthFormated(date) {
   if(!date)
     date = new Date();

     month = date.getMonth(); 
    return month < 9 ? "0" + (month+1) : month+1;
};
	$('#showBillMonth').val(monthFormated()).change();
	var e = document.getElementById("showBillMonth");
var month = e.value;

</script>

<!------------------------------------------>
<div class="container-Bill">
<section class="elec-section card" style="margin-top:2%;background: ">
<form id="form">
<label for="basic-url"></label>
   
        <div class="input-group">
        <span class="input-group-addon" id="basic-addon3">رقم الايداع</span>
        <input type="number" min="0" class="form-control" id="chargeID" >
        </div>

        <div class="jumbotron">
          <h4> ملاحظات</h4>
        <textarea class="form-control" id="chargeNote" aria-describedby="basic-addon3"></textarea>
<input type="hidden" value="<?php echo $_SESSION['userID'];?>" id="userID">
    </div>
<center>
<button class="btn btn-success" id="saveCharge">حفظ</button><br>
</center>

</form>
		</section>
        <div id="userFlatsName"></div>
</div>
<!------------------------------------------>
<?php
include("footer.php");
?>
<script>
jQuery(function($){
$(document).ajaxSend(function() {
    $("#overlay").fadeIn(300);　
  });
$("#saveCharge").click(function(){

	
	if($("#chargeID").val()!=null){
     	
	var sendCashData=new FormData();
	sendCashData.append('chargeID',jQuery('#chargeID').val());
 sendCashData.append('chargeNote',jQuery('#chargeNote').val());
 sendCashData.append('userID',jQuery('#userID').val());
 sendCashData.append('chargeDate',jQuery('#showBillMonth').val());
    $.ajax({
      type: 'POST',
		contentType: false,
          processData: false,
		url: 'config/saveChargeMoney.php',
		data: sendCashData,
      success: function(data){
        $("#userFlatsName").html(data);
      }
    }).done(function() {
      setTimeout(function(){
        $("#overlay").fadeOut(300);
      },500);
    });
	}
});
/*end of send fun*/
});
</script>