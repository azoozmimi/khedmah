<?php
require("head.php");
require("config/ourFunctions.php");
if(empty($_SESSION["userName"]) && $_SESSION['grant']!='admin'){ echo"<script> location.replace('index.php'); </script>";}

?>
	
	
<section class="flats-sectionTop card">
	<table>
		<tr>
				<label>
					
						<input type="number"id="flatsNumber" placeholder="رقم الشقه">
						
					
					<div class="label-text"> <i class="fa fa-home"></i>
						رقم الشقه</div>
				</label>
				<label>
					
					<div class="label-text">
						<h5 id="userFlatsName"></h5>
						<input id="userFlatsID" type="text" hidden>
						
						<input id="userID" type="text" hidden value=<?php echo $_SESSION["userID"]; ?>>
					
					</div>
				</label>
			
		</tr>
	</table>
</section>

<section class="flats-sectionTop card">
		<select id="showBillMonth" class="select-css">
				<option value="01">قبض لشهر(1)</option>
				<option value="02">قبض لشهر(2)</option>
				<option value="03">قبض لشهر(3)</option>
				<option value="04">قبض لشهر(4)</option>
				<option value="05">قبض لشهر(5)</option>
				<option value="06">قبض لشهر(6)</option>
				<option value="07">قبض لشهر(7)</option>
				<option value="08">قبض لشهر(8)</option>
				<option value="09">قبض لشهر(9)</option>
				<option value="10">قبض لشهر(10)</option>
				<option value="11">قبض لشهر(11)</option>
				<option value="12">قبض لشهر(12)</option>
			  </select>

</section>
<script>
$(".divWelcomeUser").slideDown();
$(".loader-wrapper").slideUp();
$("#loader-11").slideUp();
function monthFormated(date) {
   if(!date)
     date = new Date();

     month = date.getMonth(); 
    return month < 9 ? "0" + (month+1) : month+1;
};
	$('#showBillMonth').val(monthFormated()).change();
	var e = document.getElementById("showBillMonth");
var month = e.value;

</script>

<!------------------------------------------>
<script>
jQuery(function($){
	$("#flatsNumber").change(function(){
	$(document).ajaxSend(function() {
    $("#overlay").fadeIn(300);　
  });
	var fltsNmberF=new FormData();
	fltsNmberF.append('flatsNumber',jQuery('#flatsNumber').val());
	
    $.ajax({
      type: 'POST',
		contentType: false,
          processData: false,
		url: 'config/GetcashConfig.php',
		data: fltsNmberF,
      success: function(data){
        $("#userFlatsName").html(data);
      }
    }).done(function() {
      setTimeout(function(){
        $("#overlay").fadeOut(300);
      },500);
    });
  
	});/*end flatsNumber change--------------*/
});
</script>

<!------------------------------------------>
<div class="container-Bill">
<section class="elec-section card" style="margin-top:2%;background: ">
			<table>
				<center><h4 ><i class="glyphicon glyphicon-hom"></i>
					<font> علية <span id="reTotal"></span></font>
					</h4></center><hr>
				<tr >
					<td width="110px" > 
						المبلغ المقبوض
					</td>
					
					<td colspan="">
						
						<input type="number" min="0" id="baying"  class="form-control" style="width:100%;">
					</td>
						
				</tr>
				<td colspan="4" ><hr></td>
				<tr>
				<td colspan="4"><button id="sendCashBill" class="btn btn-success"style="width:100%;" >
					تأكيد السداد
					</button></td>
					<td></td>
					<td></td>
				</tr>
			
			</table>
		</section>
</div>
<!------------------------------------------>
<?php
include("footer.php");
?>
<script>
jQuery(function($){
$(document).ajaxSend(function() {
    $("#overlay").fadeIn(300);　
  });
$("#sendCashBill").click(function(){

	
	if($("#userFlatsID").val()!=null &&
	  $("#userID").val()!=null &&
	  $("#baying").val()!=null
	  ){
		
	var sendCashData=new FormData();
	sendCashData.append('trantID',jQuery('#userFlatsID').val());
 sendCashData.append('userID',jQuery('#userID').val());
sendCashData.append('baying',jQuery('#baying').val());
sendCashData.append('bayingDate',jQuery('#showBillMonth').val());

    $.ajax({
      type: 'POST',
		contentType: false,
          processData: false,
		url: 'config/inserCashConfig.php',
		data: sendCashData,
      success: function(data){
        $("#userFlatsName").html(data);
      }
    }).done(function() {
      setTimeout(function(){
        $("#overlay").fadeOut(300);
      },500);
    });
	}
});
/*end of send fun*/
});
</script>