<style>#loader-11 { width: 100%; height: 100%; z-index: 2; } #loader-11 #loader:first-child div { display: block; width: 100px; height: 100px; border: 3px solid #ddd; border-radius: 50%; position: absolute; top: 0; right: 0; bottom: 0; left: 0; margin: auto; } #loader-11 #loader:first-child>div>div { width: 90px; height: 90px; border: 5px solid #000; border-radius: 50%; margin: auto; overflow: hidden; } #loader-11 #loader:first-child div div div { width: 110px; height: 110px; margin: auto; top: 360px; background-color: #ddd; border-radius: 0%; border: none; -webkit-animation: anim 3s ease infinite alternate, color 4s ease infinite alternate; -moz-animation: anim 3s ease infinite alternate, color 4s ease infinite alternate; -o-animation: anim 3s ease infinite alternate, color 4s ease infinite alternate; animation: anim 3s ease infinite alternate, color 4s ease infinite alternate; } @-webkit-keyframes anim { 100% { top: 0 } } @-moz-keyframes anim { 100% { top: 0 } } @-o-keyframes anim { 100% { top: 0 } } @keyframes anim { 100% { top: 0 } } @-webkit-keyframes color { 0% { background-color: green; } 25% { background-color: green; } 50% { background-color: red; } 75% { background-color: yellow; } 100% { background-color: blue; } } @-moz-keyframes color { 0% { background-color: green; } 25% { background-color: green; } 50% { background-color: red; } 75% { background-color: yellow; } 100% { background-color: blue; } } @-o-keyframes color { 0% { background-color: green; } 25% { background-color: green; } 50% { background-color: red; } 75% { background-color: yellow; } 100% { background-color: blue; } } @keyframes color { 0% { background-color: green; } 25% { background-color: green; } 50% { background-color: red; } 75% { background-color: yellow; } 100% { background-color: blue; } } </style>
<div id="showLoader-11">
<div class="loader-wrapper" id="loader-11">
    <div id="loader">
        <div>
            <div>
                <div>
                </div>
            </div>
        </div>
    </div>
    </div>
</div>
<script>
    loaders = document.getElementsByClassName('loader-wrapper');
    loaders[0].style.display = "inline-block";

    function change(self) {
	
        for (var i = loaders.length - 1; i >= 0; i--) {
		
            loaders[i].style.display = "none";
        }
        id = self.id;
        loaders[id - 1].style.display = "inline-block";
    };
    </script>
<?php
require("head.php");

?>
<br>
<br>
<form id="LoginFRM">
<div class="signInDiv" >

    <label>
        <input name="name" id="name" type="text" required />
        <div class="label-text">رقم الشقة   او اسم المستخدم</div>
    </label>
   
    <label>
        <input type="password" name="pass" id="pass" required />
        <div class="label-text">كلمة السر</div>
    </label>
	<a href="#">
		<button  type="submit" id="signINbtn" class="form-control">دخول</button></a>
</div>
</form>
<center><div class="showError"></div></center>

<script>
$(window).on('load', function () {

	$("#showLoader-11").slideUp();
  $(document).ajaxSend(function() {
    $("#overlay").fadeIn(100);　
  });
		 
  $('#LoginFRM').submit(function(event){
    event.preventDefault();
	   var form12 = new FormData();
	   form12.append('name', $('#name').val());
	  form12.append('pass', $('#pass').val());
	  
    $.ajax({
      type: 'POST',
		contentType: false,
          processData: false,
		  url:'loginConfig.php',
          data : form12,
		  success: function(data){
			    if(data=='!'|| data=='error'){
			jQuery('.showError').slideDown();
				jQuery('.showError').html('خطاء في البيانات...يرجى اعادة المحاولة');
			  jQuery('.showError').append(data);
			  jQuery('.showError').slideUp(5000);
				}else if(data=='a'){
				window.location.href='home.php'; 
				}else if(data=='u'){
				window.location.href='userShow.php';	
				}
      },
    }).done(function() {
      setTimeout(function(){
		
        $("#overlay").fadeOut(300);
      },500);
		
    });
  });
	
});
$(window).bind("load", function() {
	document.getElementById("loader-11").style.display ='none';
	
});
window.addEventListener("DOMContentLoaded", function(){
	document.getElementById("loader-11").style.display ='none';
});
</script>
<?php
require_once("footer.php");