<?php
require_once("head.php");
require_once("config/conn.php");
try{
	$db_wSignPrice=0;
	$db_wUnitPrice=0;
	$db_eSignPrice=0;
	$db_eUnitPrice=0;
	$sql2="select * from waterbill ORDER BY ID DESC LIMIT 1;";
	$pdo2=$conn->prepare($sql2);
	$pdo2->execute();
		$fullInfo2=$pdo2->fetchall();
		
            foreach($fullInfo2 as $info)
			{
				$db_wUnitPrice=$info['wUnitPrice'];
				$db_wSignPrice=$info['wSignPrice'];
			}
	$sql="select * from elecbill ORDER BY ID DESC LIMIT 1;";
	$pdo=$conn->prepare($sql);
	$pdo->execute();
		$fullInfo=$pdo->fetchall();
		
            foreach($fullInfo as $info)
			{
				$db_eSignPrice=$info['signPrice'];
				$db_eUnitPrice=$info['unitPrice'];
			}
}catch(PDOException $x){echo $x->getMessage();}

?>
<script>
jQuery(document).ready(function(){
	jQuery("#elecDiv").slideDown();
jQuery("#wEaddBill").submit(function(){return false;});
jQuery("#elecNext").click(function(){
if($("#elecPrice").val()!="" && $("#elecValue").val()!="" ){
jQuery("#elecDiv").slideUp();
jQuery("#water").slideDown();	
}else{
	
}

});/*end of elecNext click*/
	
jQuery("#wEaddBillSubmit").click(function(){
if($("#waterPrice").val()!="" && $("#waterValue").val()!="" ){
jQuery("#water").slideUp();
if($("#waterPrice").val()==$("#realwaterPrice").val() &&
 $("#waterValue").val()==$("#realwaterValue").val()&&	
  $("#elecPrice").val()==$("#realelecPrice").val()&&
$("#elecValue").val()==$("#realelecValue").val()){
	window.location='addBills.php';
}else{ 
$(document).ajaxSend(function() {
    $("#overlay").fadeIn(300);　
  });
	var addwEBill=new FormData();
	addwEBill.append('waterPrice',$("#waterPrice").val());
	addwEBill.append('waterValue',$("#waterValue").val());
	addwEBill.append('elecPrice',$("#elecPrice").val());
	addwEBill.append('elecValue',$("#elecValue").val());
	
    $.ajax({
      type: 'POST',
		contentType: false,
          processData: false,
url:'config/wEsave.php',
			data: addwEBill,
      success: function(data){
if(data=='s'){
window.location.href='addBills.php';	}
else{
		 $("#wEaddBillDiv").html(data);
}
		  
      }
    }).done(function() {
      setTimeout(function(){
        $("#overlay").fadeOut(300);
      },500);
    });
 
}
}
	
});/*end of elecNext click*/
 
	
});
	
</script>


<div id="wEaddBillDiv">
		<form id="wEaddBill" method="post" >
			<div class="card " style=" margin:4%;" id="elecDiv">
				<h1 style="text-align:center;">فاتورة الكهرباء</h1><hr>
				<label>
					<input type="number" id="elecPrice" placeholder="سعر الوحده" require value=<?php  echo "$db_eUnitPrice"; ?> >
					<input type="number" id="realelecPrice" value=<?php  echo "$db_eUnitPrice"; ?> hidden >
					<div class="label-text"> سعر الوحده</div>
				</label>
				<label>
					<input type="number" id="elecValue" placeholder="سعر الاشتراك" require value=<?php  echo "$db_eSignPrice"?> >
					<input type="number" id="realelecValue"  value=<?php  echo "$db_eSignPrice"?> hidden >
					<div class="label-text" > سعر الاشتراك</div>
				</label>
				<label>
					<button class="" id="elecNext"><i class="fa fa-toggle-right"></i>التالي</button>
				</label>
				
			</div>
			
			
			<div class="card " style=" margin:4%;"  id="water">
				<h1 style="text-align:center;">فاتورة الماء</h1><hr>
				<label>
					<input type="number" id="waterPrice" placeholder="سعر الوحده" require value=<?php  echo "$db_wUnitPrice"?>>
					<input type="number" id="realwaterPrice"  value=<?php  echo "$db_wUnitPrice"?> hidden>
					<div class="label-text"> سعر الوحده</div>
				</label>
				<label>
					<input type="number" id="waterValue" placeholder="سعر الاشتراك" require value=<?php  echo "$db_wSignPrice"?> >
					<input type="number" id="realwaterValue" value=<?php  echo "$db_wSignPrice"?> hidden>
					<div class="label-text"> سعر الاشتراك</div>
				</label>
				
				<label>
					<button type="submit" id="wEaddBillSubmit" class="button"><i class="fa fa-toggle-right"></i>التالي</button>
				</label>
			</div>
			
		</form>	
</div>
